
### remark
### _7: scanerio2, 7b: scnaerio1, 7c:scanerio3

########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}

tempenv1 <- new.env()
tempenv2 <- new.env()
tempenv3 <- new.env()

load("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/MCMC_result_scenario2.Rdata", envir=tempenv1)
load("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/MCMC_result_scenario1.Rdata", envir=tempenv2)
load("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/MCMC_result_scenario3.Rdata", envir=tempenv3)

pp1 <- para_summary(tempenv1$tt[[1]][1001:11000,],4,3,0)
pp2 <- para_summary(tempenv2$tt[[1]][1001:11000,],4,3,0)
pp3 <- para_summary(tempenv3$tt[[1]][1001:11000,],4,3,0)

p1 <- para_summary(tempenv1$tt[[1]][1001:11000,],4,3,0)

### this doesn't matter because it did not used
a1 <- cbind(tt[[1]][,c(63,66,64,67)]-tt[[1]][,c(62,65,62,65)])
a2 <- para_summary(a1,4,3,0)
###


orderset <- c(61,62,65,63,66,64,67,68:72)

record <- matrix(NA,15,3)
record1 <- matrix(NA,15,3)
record2 <- matrix(NA,15,3)
record3 <- matrix(NA,15,3)

for (i in 1:12){
  record[i,1:3] <- p1[orderset[i],1:3]
  record1[i,1:3] <- pp1[orderset[i],1:3]
  record2[i,1:3] <- pp2[orderset[i],1:3]
  record3[i,1:3] <- pp3[orderset[i],1:3]
}


record <- exp(record)
record1 <- exp(record1)
record2 <- exp(record2)
record3 <- exp(record3)

plotdata <- log2(record)



tableform <- function(record){
output1 <- paste(record[,1]," (",record[,2],", ",record[,3],")",sep="")
output <- matrix(" ",26,1)
output[c(4,7,8,12,16,13,17,20,23:26)] <- output1[1:12]
output[c(3,6,11,15,19,22)] <- "Ref"
output[1] <- "Odds ratio"

output2 <- matrix(" ",26,2)
output2[,1] <- c(" ","Age"," 2-8"," >8","Number of prior infection"," 0"," 1"," >1","Number of prior infection, years since last infection","With 1 prior infection"," 1, 1 year",
                 " 1, 2 years"," 1, >2 years","With >1 prior infection"," >1, 1 year"," >1, 2 years"," >1, >2 years","House ownership","No","Yes","Number of fans","0","1-2","3-4","5-6",">6")
output2[,2] <- output
output2[1,2] <- "Odds ratio"
return(output2)
}

a1 <- tableform(round(record1,2))
a2 <- tableform(round(record2,2))
a3 <- tableform(round(record3,2))

aa1 <- cbind(a1,a2,a3)

aa1 <- aa1[,c(1,4,2,6)]
aa1[1,2:4] <- c("Scanerio 1","Scanerio 2","Scanerio 3")

aa2 <- aa1[c(3:4,6:8,11:13,15:17,19:20,22:26),2:4]

write.table(aa2,"/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/TableS4.csv",row.names = F, col.names = F,sep = ",")

