
data1 <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/from yang/data/Managua_case.csv")
data2 <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/from yang/data/national_case.csv")
data3 <- read.table("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/from yang/data/reported_n.txt")
data4 <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/from yang/data/national_case2.csv")
data5 <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/from yang/data/Managua_case1.csv")
data6 <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/from yang/data/national_case21.csv")

data31 <- data3
for (i in 1:ncol(data31)){
  data31[,i] <- data31[,i]/sum(data31[,i])  
}


data11 <- data1[,-1]
data41 <- data4[,-1]
data51 <- data5[,-1]
data61 <- data6[,-1]


##  no mention then 1, mention, then 5, with some mention, then 10?
# with 2- 80 10 5 5
# with 3- 75 10 10 5
# with 1- 85 5 5 5
# 2 col circulate - 45 45 5 5

## serotype from paho
# 1995. DENV 1-3 # DENV 3 major with some DENV 2, harris_2000   # type 2
# 1996. DENV NA   #DENV 4 major??  # type 3
# 1997. DENV NA                 # type 3
# 1998. DENV 2-3 # 90% denv-3, 10% denv-2, from eva harris report on 1998 epidemic   # type 3
# 1999. DENV 2-3 # 21:2:3 # from hammond  #type 2 
# 2000. DENV 2-4 # 21:2:3             # type 2
# 2001. DENV 2-3 # 21:2:3             # type 2
# 2002. DENV 1,2,4    # DENV 1,2      # type 1 
# 2003. DENV 1                        # type 1
# 2004. DENV 1,2,4    # 1:9, 2:3, 4:1  # type 1
# 2005. DENV 1,2,4    # 1:24, 2:31  # type 1 and 2
# 2006. DENV 1,2,4    # 1:1, 2:9    # type 2
# 2007. DENV 1,2,3    # 1:1, 2:61   # type 2
# 2008. DENV 1,2,3,4  # 2:2, 3:19   # type 3
# 2009. DENV 1,2,3    # 1:18, 2:9, 3:141 # type 3

serotype1 <- matrix(NA,4,15)
serotype1[,1] <- c(1,1,2,0)
serotype1[,c(2,3)] <- rep(c(0,0,2,0),2)
serotype1[,4] <- c(0,1,2,0)
serotype1[,c(5,7)] <- rep(c(0,2,1,0),2)
serotype1[,6] <- c(0,2,1,1)
serotype1[,c(8,10)] <- rep(c(2,1,0,1),2)
serotype1[,9] <- c(2,0,0,0)
serotype1[,11] <- c(2,2,0,1)
serotype1[,12] <- c(1,2,0,1)
serotype1[,13] <- c(1,2,1,0)
serotype1[,14] <- c(1,1,2,1)
serotype1[,15] <- c(1,1,2,0)

serotype2 <- serotype3 <- serotype4 <- serotype1

for (i in 1:15){
  temp1 <- temp2 <- temp3 <- serotype1[,i]  
  temp1[temp1==0] <- 0.02
  temp1[temp1==1] <- 0.05
  temp1[temp1==2] <- 1-sum(temp1[temp1!=2])
  serotype2[,i] <- temp1
  
  temp2[temp2==0] <- 0.02
  temp2[temp2==1] <- 0.10
  temp2[temp2==2] <- 1-sum(temp2[temp2!=2])
  serotype3[,i] <- temp2
  
  temp3[temp3==0] <- 0.02
  temp3[temp3==1] <- 0.15
  temp3[temp3==2] <- 1-sum(temp3[temp3!=2])
  serotype4[,i] <- temp3
  
}
serotype2[1:2,11] <- serotype2[1:2,11]/2
serotype3[1:2,11] <- serotype3[1:2,11]/2
serotype4[1:2,11] <- serotype4[1:2,11]/2


## serotype from paho
# 1995. DENV 1-3 # DENV 3 major with some DENV 2, harris_2000   # type 2
# 1996. DENV NA   #DENV 4 major??  # type 3
# 1997. DENV NA                 # type 3
# 1998. DENV 2-3 # 90% denv-3, 10% denv-2, from eva harris report on 1998 epidemic   # type 3
# 1999. DENV 2-3 # 21:2:3 # from hammond  #type 2 
# 2000. DENV 2-4 # 21:2:3             # type 2
# 2001. DENV 2-3 # 21:2:3             # type 2
# 2002. DENV 1,2,4    # DENV 1,2      # type 1 
# 2003. DENV 1                        # type 1
# 2004. DENV 1,2,4    # 1:9, 2:3, 4:1  # type 1
# 2005. DENV 1,2,4    # 1:24, 2:31  # type 1 and 2
# 2006. DENV 1,2,4    # 1:1, 2:9    # type 2
# 2007. DENV 1,2,3    # 1:1, 2:61   # type 2
# 2008. DENV 1,2,3,4  # 2:2, 3:19   # type 3
# 2009. DENV 1,2,3    # 1:18, 2:9, 3:141 # type 3
serotype2[c(1,2,4),10] <- 0.98*c(9,3,1)/13
serotype2[c(1,2),11] <- 0.93*c(24,31)/45
serotype2[c(1,2),12] <- 0.93*c(1,9)/10
serotype2[c(2,3),14] <- 0.9*c(2,19)/21
serotype2[c(1,2,3),15] <- 0.98*c(18,9,141)/168

serotype3[c(1,2,4),10] <- 0.97*c(9,3,1)/13
serotype3[c(1,2),11] <- 0.89*c(24,31)/45
serotype3[c(1,2),12] <- 0.89*c(1,9)/10
serotype3[c(2,3),14] <- 0.84*c(2,19)/21
serotype3[c(1,2,3),15] <- 0.97*c(18,9,141)/168

serotype4[c(1,2,4),10] <- 0.96*c(9,3,1)/13
serotype4[c(1,2),11] <- 0.85*c(24,31)/45
serotype4[c(1,2),12] <- 0.85*c(1,9)/10
serotype4[c(2,3),14] <- 0.78*c(2,19)/21
serotype4[c(1,2,3),15] <- 0.96*c(18,9,141)/168

## data1: managua confirm case
## data2: paho data
## data4: nicaragya confirm case
## data5: managua suspect case
## data6: nicarage suspect case

## use the old data to create a shape data

data12 <- data13 <- matrix(NA,nrow(data11),2)
data42 <- data43 <- matrix(NA,nrow(data41),2)
data52 <- data53 <- matrix(NA,nrow(data51),2)
data62 <- data63 <- matrix(NA,nrow(data61),2)

## this is the number sum for every half year
for (i in 1:2){
  data12[,i] <- rowSums(data11[,1:26+(i-1)*26],na.rm=T)
  data42[,i] <- rowSums(data41[,1:26+(i-1)*26],na.rm=T)
  data52[,i] <- rowSums(data51[,1:26+(i-1)*26],na.rm=T)
  data62[,i] <- rowSums(data61[,1:26+(i-1)*26],na.rm=T)
}

## change to epidemic year
for (i in 1:14){
  data13[i,1] <- data12[i,2] + data12[i+1,1]
  data43[i,1] <- data42[i,2] + data42[i+1,1]
  data53[i,1] <- data52[i,2] + data52[i+1,1]
  data63[i,1] <- data62[i,2] + data62[i+1,1]
}

data13[,2] <- rowSums(data12)
data43[,2] <- rowSums(data42)
data53[,2] <- rowSums(data52)
data63[,2] <- rowSums(data62)

data2$x11 <- data2$x12 <- NA
data2$x21 <- data2$x22 <- NA
data2$x31 <- data2$x32 <- NA
data2$x41 <- data2$x42 <- NA
data2[6+0:13,c("x11","x12")] <- data13[1:14,] 
data2[6+0:13,c("x21","x22")] <- data43[1:14,] 
data2[6+0:13,c("x31","x32")] <- data53[1:14,] 
data2[6+0:13,c("x41","x42")] <- data63[1:14,] 

## data1: managua confirm case
## data2: paho data
## data4: nicaragya confirm case
## data5: managua suspect case
## data6: nicarage suspect case

## compute the ratio first for nigaragua first
data2$r21 <- data2$x22/data2[,2]
data2$r41 <- data2$x42/data2[,2]
## seems like the pato before 2000 is suspect case, not confirm, so use the ratio to impute first
data2$x42[1:5] <- data2[1:5,2]
data2$x22[1:5] <- data2[1:5,2]*0.137898

## compute the ratio to use nicaragua case to impute the managua case
data2$r21 <- data2$x22/data2$x12
data2$r41 <- data2$x42/data2$x32
## the ratio is around 3.6-3.8, take 3.7 then
data2$x12[1:5] <- data2$x22[1:5]/3.28
data2$x32[1:5] <- data2$x42[1:5]/3.62

### then we need to compute the ratio for each epidemic
## use the data12-42 to compute
r12 <- matrix(NA,15,1)
r42 <- matrix(NA,15,1)
r52 <- matrix(NA,15,1)
r62 <- matrix(NA,15,1)

for (i in 1:14){
  r12[i] <-   data12[i,2]/data12[i+1,1]
  r42[i] <-   data42[i,2]/data42[i+1,1]
  r52[i] <-   data52[i,2]/data52[i+1,1]
  r62[i] <-   data62[i,2]/data62[i+1,1]
}

## for suspect, take 2.3, for confirm, take 3.98
## get the data out first
epiyear1 <- matrix(NA,15,5)
epiyear1[,1:2] <- as.matrix(data2[1:15,c("x12","x11")])
epiyear1[6:15,3:4] <- data12[1:10,]
for (i in 5:1){
  epiyear1[i,4] <- epiyear1[i+1,3]*3.98
  epiyear1[i,3] <- epiyear1[i,1]-epiyear1[i,4]
}

epiyear2 <- matrix(NA,15,5)
epiyear2[,1:2] <- as.matrix(data2[1:15,c("x32","x31")])
epiyear2[6:15,3:4] <- data52[1:10,]
for (i in 5:1){
  epiyear2[i,4] <- epiyear2[i+1,3]*2.3
  epiyear2[i,3] <- epiyear2[i,1]-epiyear2[i,4]
}


data2$x31[1:5] <- data2$x32[1:5]

n.managua1<-c(1895, 4042, 4377,3119,2702,2581,1714,3663,2590,7996,9802,2323,10487,17086,6262)
n.nicaragua1<-c(8106,16568,16737,8700,8423,14726,10524,12447,8851,18123,25357,11891,30524,68996,29891)
r <- n.managua1/n.nicaragua1

case <- data2[1:15,3]*0.3
case2 <- c(data2[1:5,3]*0.3,data2[6:15,3]*r[6:15-5])
newdata11 <- round(t(case*t(serotype2)))
newdata21 <- round(t(case*t(serotype3)))
newdata31 <- round(t(case*t(serotype4)))
newdata12 <- round(t(case2*t(serotype2)))
newdata22 <- round(t(case2*t(serotype3)))
newdata32 <- round(t(case2*t(serotype4)))



pdf("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/figureS1.pdf",width=12, height=12)
layout(matrix( 1:2, ncol=1,byrow=T))


################################################################################################################################
# panel A

sur <- newdata12
sur2 <- newdata22
sur3 <- newdata32

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0.8,16), ylim=c(0,7000),type="n")

axis(1,at=c(1:15),labels=1995+0:14,cex.axis=1)
axis(2,at=0:7*1000, las=1, pos=0.55)

lines(1:15,sur[1,],col="black")
lines(1:15,sur[2,],col="red")
lines(1:15,sur[3,],col="blue")
lines(1:15,sur[4,],col="green")

points(1:15,sur[1,],col="black",pch=16,cex=cexpara)
points(1:15,sur[2,],col="red",pch=16,cex=cexpara)
points(1:15,sur[3,],col="blue",pch=16,cex=cexpara)
points(1:15,sur[4,],col="green",pch=16,cex=cexpara)

lines(1:15,sur2[1,],col="black",lty=2)
lines(1:15,sur2[2,],col="red",lty=2)
lines(1:15,sur2[3,],col="blue",lty=2)
lines(1:15,sur2[4,],col="green",lty=2)

points(1:15,sur2[1,],col="black",pch=17,cex=cexpara,lty=2)
points(1:15,sur2[2,],col="red",pch=17,cex=cexpara,lty=2)
points(1:15,sur2[3,],col="blue",pch=17,cex=cexpara,lty=2)
points(1:15,sur2[4,],col="green",pch=17,cex=cexpara,lty=2)

lines(1:15,sur3[1,],col="black",lty=3)
lines(1:15,sur3[2,],col="red",lty=3)
lines(1:15,sur3[3,],col="blue",lty=3)
lines(1:15,sur3[4,],col="green",lty=3)

points(1:15,sur3[1,],col="black",pch=18,cex=cexpara,lty=3)
points(1:15,sur3[2,],col="red",pch=18,cex=cexpara,lty=3)
points(1:15,sur3[3,],col="blue",pch=18,cex=cexpara,lty=3)
points(1:15,sur3[4,],col="green",pch=18,cex=cexpara,lty=3)

mtext("Count",side=2,line=3)
mtext("Year",side=1,line=3)


legend(5,7000,c("Scenario 1","Scenario 2","Scenario 3"),pch=16:18,cex=1,lty=1:3)

legend(7.5,7000,c("DENV-1","DENV-2","DENV-3","DENV-4"),cex=1,col=c("black","red","blue","green"),lty=1)


### panel B

sur <- serotype2
sur2 <- serotype3
sur3 <- serotype4

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0.8,16), ylim=c(0,1),type="n")

axis(1,at=c(1:15),labels=1995+0:14,cex.axis=1)
axis(2,at=0:5*0.2, las=1, pos=0.55)

lines(1:15,sur[1,],col="black")
lines(1:15,sur[2,],col="red")
lines(1:15,sur[3,],col="blue")
lines(1:15,sur[4,],col="green")

points(1:15,sur[1,],col="black",pch=16,cex=cexpara)
points(1:15,sur[2,],col="red",pch=16,cex=cexpara)
points(1:15,sur[3,],col="blue",pch=16,cex=cexpara)
points(1:15,sur[4,],col="green",pch=16,cex=cexpara)

lines(1:15,sur2[1,],col="black",lty=2)
lines(1:15,sur2[2,],col="red",lty=2)
lines(1:15,sur2[3,],col="blue",lty=2)
lines(1:15,sur2[4,],col="green",lty=2)

points(1:15,sur2[1,],col="black",pch=17,cex=cexpara,lty=2)
points(1:15,sur2[2,],col="red",pch=17,cex=cexpara,lty=2)
points(1:15,sur2[3,],col="blue",pch=17,cex=cexpara,lty=2)
points(1:15,sur2[4,],col="green",pch=17,cex=cexpara,lty=2)

lines(1:15,sur3[1,],col="black",lty=3)
lines(1:15,sur3[2,],col="red",lty=3)
lines(1:15,sur3[3,],col="blue",lty=3)
lines(1:15,sur3[4,],col="green",lty=3)

points(1:15,sur3[1,],col="black",pch=18,cex=cexpara,lty=3)
points(1:15,sur3[2,],col="red",pch=18,cex=cexpara,lty=3)
points(1:15,sur3[3,],col="blue",pch=18,cex=cexpara,lty=3)
points(1:15,sur3[4,],col="green",pch=18,cex=cexpara,lty=3)

mtext("Proportion",side=2,line=3)
mtext("Year",side=1,line=3)




dev.off()
