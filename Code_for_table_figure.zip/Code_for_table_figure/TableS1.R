
## table 1 is the basic number of infection

data <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/data/2017_05_22.csv")
data1 <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/data/2017_05_22_2.csv")

data1$age <- ceiling(data1$age)

table1 <- matrix(NA,19,12)
for (i in 1:6){
# number of participant
table1[1,2*i-1] <- sum(!is.na(data1[,4*i+2]))  
# Age
table1[2,2*i-1] <- sum(data1$age+i-data1$first_year<=5 & data1$age+i-data1$first_year>=data1$age &!is.na(data1[,4*i+2]))  
table1[3,2*i-1] <- sum(data1$age+i-data1$first_year>5&data1$age+i-data1$first_year<=8 &!is.na(data1[,4*i+2])) 
table1[4,2*i-1] <- sum(data1$age+i-data1$first_year>8 &!is.na(data1[,4*i+2])) 
# Sex
table1[5,2*i-1] <- sum(data1$sex==1 &!is.na(data1[,4*i+2]))  
table1[6,2*i-1] <- sum(data1$sex==2 &!is.na(data1[,4*i+2])) 
#  lab test for pair sera
table1[7,2*i-1] <- sum(data1[,4*i+5]==2 &!is.na(data1[,4*i+5]) &!is.na(data1[,4*i+2]) )  
table1[8,2*i-1] <- sum(data1[,4*i+5]==3 &!is.na(data1[,4*i+5]) &!is.na(data1[,4*i+2]) )  
table1[9,2*i-1] <- sum(data1[,4*i+5]%in%c(4,5) &!is.na(data1[,4*i+5]) &!is.na(data1[,4*i+2]) )  
# infection
table1[10,2*i-1] <- sum(data1[,4*i+2]==1 & data1[,4*i+5]==1 &!is.na(data1[,4*i+5]) &!is.na(data1[,4*i+2]) )  
table1[11,2*i-1] <- sum(data1[,4*i+2]==1 & data1[,4*i+5]==2 &!is.na(data1[,4*i+5]) &!is.na(data1[,4*i+2]) )  
table1[12,2*i-1] <- sum(data1[,4*i+2]==1 & data1[,4*i+5]==3 &!is.na(data1[,4*i+5]) &!is.na(data1[,4*i+2]) )  
table1[13,2*i-1] <- sum(data1[,4*i+2]==1 & data1[,4*i+5]%in%c(4,5) &!is.na(data1[,4*i+5]) &!is.na(data1[,4*i+2]) )  
table1[14,2*i-1] <- sum(data1[,4*i+2]==1 &!is.na(data1[,4*i+5]) &!is.na(data1[,4*i+2]) )  
# Serotype
table1[15,2*i-1] <- sum(data1[,4*i+4]==1 &!is.na(data1[,4*i+2]) )  
table1[16,2*i-1] <- sum(data1[,4*i+4]==2 &!is.na(data1[,4*i+2]) )  
table1[17,2*i-1] <- sum(data1[,4*i+4]==3 &!is.na(data1[,4*i+2]) )  
table1[18,2*i-1] <- sum(data1[,4*i+4]==4 &!is.na(data1[,4*i+2]) )  
table1[19,2*i-1] <- sum(data1[,4*i+4]==9 &!is.na(data1[,4*i+2]) ) 

table1[1:9,2*i] <- round(table1[1:9,2*i-1]/table1[1,2*i-1]*100)
table1[10:19,2*i] <- round(table1[10:19,2*i-1]/table1[14,2*i-1]*100)
}

table11 <- matrix(NA,nrow(table1),6)
for (i in 1:6){
table11[,i] <- paste(table1[,2*i-1]," (",table1[,2*i],")",sep="")  
}
table11[1,] <- table1[1,1:6*2-1]
table11[14,] <- table1[14,1:6*2-1]

write.table(table11,"/Users/timtsang/Dropbox2/Dropbox/Nicaragua/version/natcomm/tableS1.csv",row.names = F, col.names = F,sep = ",")
write.table(table11,"/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/tableS1.csv",row.names = F, col.names = F,sep = ",")

