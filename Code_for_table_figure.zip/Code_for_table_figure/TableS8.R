


load("MCMC_result_sen1.Rdata")

prnt <- read.csv("/Volumes/GoogleDrive/My Drive/Nicaragua/data/2017_05_22_prnt.csv")
rvp <- read.csv("/Volumes/GoogleDrive/My Drive/Nicaragua/data/2017_05_22_rvp.csv")


prnt_org <- prnt[,1:6]
prnt <- prnt[,1:6]
for (i in 3:6){
  prnt[prnt[,i]<=8&!is.na(prnt[,i]),i] <- 0  
  prnt[prnt[,i]>8&prnt[,i]<=39&!is.na(prnt[,i]),i] <- 1  
  prnt[prnt[,i]>39&!is.na(prnt[,i]),i] <- 2  
}
prnt2 <- reshape(prnt,timevar="serotype",direction="wide")
names(prnt2)[2:ncol(prnt2)] <- paste("prnt_",names(prnt2)[2:ncol(prnt2)],sep="")

quantile(as.vector(as.matrix(prnt[,3:6])),c(1/3,2/3),na.rm=T)

prnt_org2 <- reshape(prnt_org,timevar="serotype",direction="wide")
names(prnt_org2)[2:ncol(prnt_org2)] <- paste("prnt_org_",names(prnt_org2)[2:ncol(prnt_org2)],sep="")

rvp_org <- rvp[,1:9]
rvp <- rvp[,1:9]
for (i in 2:8){
  rvp[rvp[,i]<=5&!is.na(rvp[,i]),i] <- 0
  rvp[rvp[,i]>5&rvp[,i]<=39&!is.na(rvp[,i]),i] <- 1
  rvp[rvp[,i]>39&!is.na(rvp[,i]),i] <- 2
}

rvp2 <- reshape(rvp,timevar="serotype",direction="wide")
names(rvp2)[2:ncol(rvp2)] <- paste("rvp_",names(rvp2)[2:ncol(rvp2)],sep="")

quantile(as.vector(as.matrix(rvp[,2:8])),c(1/3,2/3),na.rm=T)

rvp_org2 <- reshape(rvp_org,timevar="serotype",direction="wide")
names(rvp_org2)[2:ncol(rvp_org2)] <- paste("rvp_org_",names(rvp_org2)[2:ncol(rvp_org2)],sep="")

data1 <- merge(data1,prnt2,by="id",all.x=T)
data1 <- merge(data1,prnt_org2,by="id",all.x=T)
data1 <- merge(data1,rvp2,by="id",all.x=T)
data1 <- merge(data1,rvp_org2,by="id",all.x=T)

# ELISA: <21,21-80, 81-320, 321-1280, >1280

temp <- as.vector(as.matrix(data1[,46:52]))
temp <- temp[temp>0]
quantile(temp,c(1/3,2/3),na.rm=T)

## 40-45 copy the original ELISA value
data1[,152:157] <- data1[,46:51]

for (i in c(46:51)){
  data1[data1[,i]==1&!is.na(data1[,i]),i] <- 0
  data1[data1[,i]>1&data1[,i]<21&!is.na(data1[,i]),i] <- 1  
  data1[data1[,i]>=21&data1[,i]<81&!is.na(data1[,i]),i] <- 2
  data1[data1[,i]>=81&data1[,i]<321&!is.na(data1[,i]),i] <- 3  
  data1[data1[,i]>=321&data1[,i]<1281&!is.na(data1[,i]),i] <- 4  
  data1[data1[,i]>=1281&!is.na(data1[,i]),i] <- 5
}



u1 <- tt[[12]][1001:11000,]
s1 <- tt[[13]][1001:11000,]

# record matrix


### symptomatic infection as outcome
## infection
result1 <- matrix(NA,10000,70)
result2 <- matrix(NA,10000,70)

## symptomatic infection
result3 <- matrix(NA,10000,70)
result4 <- matrix(NA,10000,70)

## disease given infection
result5 <- matrix(NA,10000,70)
result6 <- matrix(NA,10000,70)


aaaaa1 <- Sys.time()
for (jj in 1:10){
  print(jj)
  u2 <- u1[jj,]
  u3 <- matrix(as.matrix(u2),ncol=4,byrow=T)
  s2 <- s1[jj,]
  s3 <- matrix(as.matrix(s2),ncol=4,byrow=T)
  ## compute the number of prior infection in each study variable
  u3 <- cbind(data1[,c(3)],1*(rowSums(data1[,11:14]!=0)==0),u3,s3)
  
  
  
  ## 1 is age, 2 is baseline positive
  
  ##
  u4 <- cbind(data1,u3)
  #u4 <- u4[rowSums(u4[,154:157]>=u4[,152])>0,]
  u4[,168:173] <- 0
  
  for (i in 0:5){
    u4[,168+i] <- rowSums(u4[,160:163] < u4[,3] + i - u4[,5] + 1 & u4[,160:163]!=0)
  }
  
  #sinf <- list(NA)
  #sinf[[1]] <- which(u4[,154]>=u4[,152])
  #sinf[[2]] <- which(u4[,155]>=u4[,152])
  #sinf[[3]] <- which(u4[,156]>=u4[,152])
  #sinf[[4]] <- which(u4[,157]>=u4[,152])
  
  ## use u4 to create data set
  alldata <- matrix(NA,nrow(u4)*6,27)
  
  # 1. infection, 2. symptomatic infection, 3. number of prior infection 4 ELISA, 5, ELISA group, 6. number of infection =1 and >1 group, 7 is the regroup of elisa group + number of prior infection
  # 8. the study year
  # 9-12. rvp1-4 group
  # 13-16. rvp1-4 
  # 17-20. prnt1-4 group
  # 21-24. prnt1-4
  # 25. if infection, get the serotype
  # 26. age
  # 27. id
  for (i in 0:5){
    alldata[nrow(u4)*i+1:nrow(u4),26] <- u4[,3] + i - u4[,5] + 1
    alldata[nrow(u4)*i+1:nrow(u4),27] <- u4[,1]
    alldata[nrow(u4)*i+1:nrow(u4),1] <- u4[,20+i*5]
    alldata[nrow(u4)*i+1:nrow(u4),2] <- u4[,54+i]
    alldata[nrow(u4)*i+1:nrow(u4),3] <- u4[,168+i]
    alldata[nrow(u4)*i+1:nrow(u4),4] <- u4[,152+i]
    alldata[nrow(u4)*i+1:nrow(u4),5] <- u4[,46+i]
    alldata[nrow(u4)*i+1:nrow(u4),8] <- i+1
    alldata[nrow(u4)*i+1:nrow(u4),9] <- u4[,i+96]
    alldata[nrow(u4)*i+1:nrow(u4),10] <- u4[,i+103]
    alldata[nrow(u4)*i+1:nrow(u4),11] <- u4[,i+110]
    alldata[nrow(u4)*i+1:nrow(u4),12] <- u4[,i+117]
    alldata[nrow(u4)*i+1:nrow(u4),13] <- u4[,i+124]
    alldata[nrow(u4)*i+1:nrow(u4),14] <- u4[,i+131]
    alldata[nrow(u4)*i+1:nrow(u4),15] <- u4[,i+138]
    alldata[nrow(u4)*i+1:nrow(u4),16] <- u4[,i+145]
    if (i <=3){
      alldata[nrow(u4)*i+1:nrow(u4),17] <- u4[,i+64]
      alldata[nrow(u4)*i+1:nrow(u4),18] <- u4[,i+68]
      alldata[nrow(u4)*i+1:nrow(u4),19] <- u4[,i+72]
      alldata[nrow(u4)*i+1:nrow(u4),20] <- u4[,i+76]
      alldata[nrow(u4)*i+1:nrow(u4),21] <- u4[,i+80]
      alldata[nrow(u4)*i+1:nrow(u4),22] <- u4[,i+84]
      alldata[nrow(u4)*i+1:nrow(u4),23] <- u4[,i+88]
      alldata[nrow(u4)*i+1:nrow(u4),24] <- u4[,i+92]
    }
    
    alldata[nrow(u4)*i+1:nrow(u4),25] <- (rowSums(u4[,16:19+i*5])==1)*(1*(u4[,16+i*5]==1)+2*(u4[,17+i*5]==1)+3*(u4[,18+i*5]==1)+4*(u4[,19+i*5]==1))
    
  }
  
  ## for ELISA
  alldata[,6] <- pmin(alldata[,3],2)
  alldata <- alldata[alldata[,1]!=-1&alldata[,3]<4,]
  alldata[,7] <- alldata[,6]*6 + alldata[,5]
  alldata[,1] <- 1*(alldata[,1]==0)
  alldata[,26] <- 1*(alldata[,26]>=9)
  
  alldata <- data.frame(alldata)
  
  ### here X1 is all infection, X2 is symptomatic infection
  ### PRNT+RVP
  ### only disease given infection
  temp <- alldata[alldata[,3]>=1&alldata[,25]!=0,]
  temp$homo <- NA
  temp$hetero <- NA
  temp$homovalue <- NA
  temp$heterovalue <- NA
  for (i in 1:4){
    temp[temp[,25]==i,]$homo <- pmax(temp[temp[,25]==i,8+i],temp[temp[,25]==i,16+i],na.rm=T) 
    hetero <- setdiff(1:4,i)
    temp[temp[,25]==i,]$hetero <-pmax(temp[temp[,25]==i,8+hetero[1]],temp[temp[,25]==i,8+hetero[2]],temp[temp[,25]==i,8+hetero[3]],
                                      temp[temp[,25]==i,16+hetero[1]],temp[temp[,25]==i,16+hetero[2]],temp[temp[,25]==i,16+hetero[3]],na.rm=T)
  }
  temp <- temp[!is.na(temp$homo),]
  ### need to relevel so that 0: high, 1: medium, 2: low
  temp$homo <- 2-temp$homo
  temp$hetero <- 2-temp$hetero
  temp$homogroup <- as.numeric(temp$homo) + as.numeric(3*temp$X6)
  ## group
  a1 <- glm(X2~as.factor(homo)+as.factor(hetero)+as.factor(X6)+as.factor(X26)+as.factor(X25),data=temp,family="binomial")
  a11 <- coef(summary(a1))
  result5[jj,1:10] <- a11[,1]
  result6[jj,1:10] <- a11[,2]
  
  a1 <- glm(X2~as.factor(homo)+as.factor(hetero)+as.factor(X6)+as.factor(X26)+as.factor(X25)+as.factor(X8),data=temp,family="binomial")
  a11 <- coef(summary(a1))
  result5[jj,51:65] <- a11[,1]
  result6[jj,51:65] <- a11[,2]
  
  ######################################################
  ## ELISA group
  a1 <- glm(X1~as.factor(X5)+as.factor(X6)+as.factor(X8)+as.factor(X26),data=alldata[alldata$X5!=-1&alldata[,3]>=1,],family="binomial")
  a11 <- coef(summary(a1))
  result1[jj,12:24] <- a11[,1]
  result2[jj,12:24] <- a11[,2]
  
  a1 <- glm(X2~as.factor(X5)+as.factor(X6)+as.factor(X8)+as.factor(X26),data=alldata[alldata$X5!=-1&alldata[,3]>=1,],family="binomial")
  a11 <- coef(summary(a1))
  result3[jj,12:24] <- a11[,1]
  result4[jj,12:24] <- a11[,2]
  
  a1 <- glm(X2~as.factor(X5)+as.factor(X6)+as.factor(X8)+as.factor(X26),data=alldata[alldata$X1==1&alldata$X5!=-1&alldata[,3]>=1,],family="binomial")
  a11 <- coef(summary(a1))
  result5[jj,12:24] <- a11[,1]
  result6[jj,12:24] <- a11[,2]
  
  ### original value
  a1 <- glm(X1~log2(X4)+as.factor(X6)+as.factor(X8)+as.factor(X26),data=alldata[alldata$X4!=-1&alldata[,3]>=1,],family="binomial")
  a11 <- coef(summary(a1))
  result1[jj,25] <- a11[2,1]
  result2[jj,25] <- a11[2,2]
  
  a1 <- glm(X2~log2(X4)+as.factor(X6)+as.factor(X8)+as.factor(X26),data=alldata[alldata$X4!=-1&alldata[,3]>=1,],family="binomial")
  a11 <- coef(summary(a1))
  result3[jj,25] <- a11[2,1]
  result4[jj,25] <- a11[2,2]
  
  a1 <- glm(X2~log2(X4)+as.factor(X6)+as.factor(X8)+as.factor(X26),data=alldata[alldata$X1==1&alldata$X4!=-1&alldata[,3]>=1,],family="binomial")
  a11 <- coef(summary(a1))
  result5[jj,25] <- a11[2,1]
  result6[jj,25] <- a11[2,2]
  
  
  ### RVP
  ### only disease given infection
  temp <- alldata[!is.na(alldata$X9)&alldata[,3]>=1&alldata[,25]!=0,]
  temp$homo <- NA
  temp$hetero <- NA
  temp$homovalue <- NA
  temp$heterovalue <- NA
  for (i in 1:4){
    temp[temp[,25]==i,]$homo <-temp[temp[,25]==i,8+i]   
    temp[temp[,25]==i,]$homovalue <-temp[temp[,25]==i,12+i]   
    hetero <- setdiff(1:4,i)
    temp[temp[,25]==i,]$hetero <-pmax(temp[temp[,25]==i,8+hetero[1]],temp[temp[,25]==i,8+hetero[2]],temp[temp[,25]==i,8+hetero[3]])
    temp[temp[,25]==i,]$heterovalue <-pmax(temp[temp[,25]==i,12+hetero[1]],temp[temp[,25]==i,12+hetero[2]],temp[temp[,25]==i,12+hetero[3]])
  }
  temp$homo <- 2-temp$homo
  temp$hetero <- 2-temp$hetero
  ## group
  a1 <- glm(X2~as.factor(homo)+as.factor(hetero)+as.factor(X6)+as.factor(X26)+as.factor(X25),data=temp,family="binomial")
  a11 <- coef(summary(a1))
  result5[jj,27:36] <- a11[,1]
  result6[jj,27:36] <- a11[,2]
  
  ## continuous
  a1 <- glm(X2~log2(homovalue)+log2(heterovalue)+as.factor(X6)+as.factor(X26)+as.factor(X25),data=temp,family="binomial")
  a11 <- coef(summary(a1))
  result5[jj,37:38] <- a11[2:3,1]
  result6[jj,37:38] <- a11[2:3,2]
  
  
  ### PRNT
  ### only disease given infection
  temp <- alldata[!is.na(alldata$X17)&alldata[,3]>=1&alldata[,25]!=0,]
  temp$homo <- NA
  temp$hetero <- NA
  temp$homovalue <- NA
  temp$heterovalue <- NA
  for (i in 1:4){
    temp[temp[,25]==i,]$homo <-temp[temp[,25]==i,16+i]   
    temp[temp[,25]==i,]$homovalue <-temp[temp[,25]==i,20+i]   
    hetero <- setdiff(1:4,i)
    temp[temp[,25]==i,]$hetero <-pmax(temp[temp[,25]==i,16+hetero[1]],temp[temp[,25]==i,16+hetero[2]],temp[temp[,25]==i,16+hetero[3]])
    temp[temp[,25]==i,]$heterovalue <-pmax(temp[temp[,25]==i,20+hetero[1]],temp[temp[,25]==i,20+hetero[2]],temp[temp[,25]==i,20+hetero[3]])
  }
  temp$homo <- 2-temp$homo
  temp$hetero <- 2-temp$hetero
  ## group
  a1 <- glm(X2~as.factor(homo)+as.factor(hetero)+as.factor(X6)+as.factor(X26)+as.factor(X25),data=temp,family="binomial")
  a11 <- coef(summary(a1))
  result5[jj,39:47] <- a11[,1]
  result6[jj,39:47] <- a11[,2]
  
  ## continuous
  a1 <- glm(X2~log2(homovalue+50)+log2(heterovalue+50)+as.factor(X6)+as.factor(X26)+as.factor(X25),data=temp,family="binomial")
  a11 <- coef(summary(a1))
  result5[jj,48:49] <- a11[2:3,1]
  result6[jj,48:49] <- a11[2:3,2]
  
}


aaaaa2 <- Sys.time()
print(aaaaa2-aaaaa1)



output1 <- matrix(NA,70,9)
for (i in 1:70){
tsd <- sd(result1[,i])+mean(result2[,i])
output1[i,1] <- mean(result1[,i])
output1[i,2] <- mean(result1[,i]) - 1.96*tsd
output1[i,3] <- mean(result1[,i]) + 1.96*tsd
tsd <- sd(result3[,i])+mean(result4[,i])
output1[i,4] <- mean(result3[,i])
output1[i,5] <- mean(result3[,i]) - 1.96*tsd
output1[i,6] <- mean(result3[,i]) + 1.96*tsd
tsd <- sd(result5[,i])+mean(result6[,i])
output1[i,7] <- mean(result5[,i])
output1[i,8] <- mean(result5[,i]) - 1.96*tsd
output1[i,9] <- mean(result5[,i]) + 1.96*tsd
}

output2 <- round(exp(output1),2)


output3 <- matrix(NA,nrow(output2),3)
output3[,1] <- paste(output2[,1]," (",output2[,2],", ",output2[,3],")",sep="")
output3[,2] <- paste(output2[,4]," (",output2[,5],", ",output2[,6],")",sep="")
output3[,3] <- paste(output2[,7]," (",output2[,8],", ",output2[,9],")",sep="")

table <- data.frame(matrix(NA,19,4))
table[,1] <- c("","ELISA","sero-negative","<=20","21-80","81-320","321-1280",">1280","log2(titer)","PRNT&RVP","Homologous, Med vs. High",
               "Homologous, Low vs. High","Heterologous, Med vs. High","Heterologous, Low vs. High","PRNT&RVP (adjusted for epidemic season)","Homologous, Med vs. High",
               "Homologous, Low vs. High","Heterologous, Med vs. High","Heterologous, Low vs. High")

table[1,1:4] <- c("Outcome","Infection","Disease","Disease given infection")

##ELISA
table[4:9,2:4] <- output3[c(13:17,25),]
## PRNT + RVP
table[11:14,4] <- output3[2:5,3]
table[16:19,4] <- output3[52:55,3]



write.table(table,"/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/TableS8.csv",row.names = F, col.names = F,sep = ",")



