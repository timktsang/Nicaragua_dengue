## conditional simulation
## for each parameter vector and infection history to do simulation


library(Rcpp)
library(RcppParallel)

load("MCMC_predict_scenario2.Rdata")

modeladeq <- tt[[18]]


agematrix <- matrix(NA,nrow(data1),6)
for (i in 1:nrow(data1)){
  #agematrix[i,(data1[i,5]:6)] <- data1[i,3]+0:(6-data1[i,5])
  
  agematrix[i,] <- (data1[i,3]-data1[i,5]+1)+0:5
}
agematrix[agematrix<=0] <- NA
#######
## direct version

probmatrix <- matrix(0,nrow(data1),18)
#probmatrix[,1:6] <- data1[,15+1:6*5]
probmatrix[,13:18] <- agematrix

probmatrix2 <- matrix(0,nrow(data1),15)
for (i in 1:nrow(data1)){
getyr <- 9+data1[i,5] -data1[i,3]+1
probmatrix2[i,getyr+0:((data1[i,3]+data1[i,6]-1-data1[i,5]))] <- modeladeq[i,1:(data1[i,3]+data1[i,6]-data1[i,5])]     
}

probmatrix[,7:12] <- probmatrix2[,10:15]


u1 <- tt[[12]][1001:11000,]
s1 <- tt[[13]][1001:11000,]
### now get the posterior
probmatrix[,1:6] <- 0
for (jj in 1:10000){
  indexnow <- jj
  print(jj)
  u2 <- u1[indexnow,]
  u3 <- matrix(as.matrix(u2),ncol=4,byrow=T)
  s2 <- s1[indexnow,]
  s3 <- matrix(as.matrix(s2),ncol=4,byrow=T)
  ## compute the number of prior infection in each study variable
  u3 <- cbind(data1[,c(3)],1*(rowSums(data1[,11:14]!=0)==0),u3,s3)
  for (j in 1:4){
  for (k in 1:6){
  probmatrix[probmatrix[,12+k]==u3[,j+2]&!is.na(probmatrix[,12+k]),k] <-  probmatrix[probmatrix[,12+k]==u3[,j+2]&!is.na(probmatrix[,12+k]),k] + 1 #/10000 
  }  
  } 
  
}
probmatrix[,1:6] <- probmatrix[,1:6]/10000



compare <- matrix(NA,18,2)
for (i in 1:6){
compare[3*i-2,1] <- sum(probmatrix[probmatrix[,12+i]<=5&!is.na(probmatrix[,12+i]),i])
compare[3*i-2,2] <- sum(probmatrix[probmatrix[,12+i]<=5&!is.na(probmatrix[,12+i]),i+6])
compare[3*i-1,1] <- sum(probmatrix[probmatrix[,12+i]>5&probmatrix[,12+i]<9&!is.na(probmatrix[,12+i]),i])
compare[3*i-1,2] <- sum(probmatrix[probmatrix[,12+i]>5&probmatrix[,12+i]<9&!is.na(probmatrix[,12+i]),i+6])
compare[3*i,1] <- sum(probmatrix[probmatrix[,12+i]>8&!is.na(probmatrix[,12+i]),i])
compare[3*i,2] <- sum(probmatrix[probmatrix[,12+i]>8&!is.na(probmatrix[,12+i]),i+6])
}

compare <- matrix(NA,12,2)
for (i in 1:6){
  compare[2*i-1,1] <- sum(probmatrix[probmatrix[,12+i]<9&!is.na(probmatrix[,12+i]),i])
  compare[2*i-1,2] <- sum(probmatrix[probmatrix[,12+i]<9&!is.na(probmatrix[,12+i]),i+6])
  compare[2*i,1] <- sum(probmatrix[probmatrix[,12+i]>8&!is.na(probmatrix[,12+i]),i])
  compare[2*i,2] <- sum(probmatrix[probmatrix[,12+i]>8&!is.na(probmatrix[,12+i]),i+6])
}

1-pchisq(sum((compare[,2]-compare[,1])^2/compare[,2]),10)

compare2 <- matrix(NA,6,2)
for (i in 1:6){
  compare2[i,1] <- sum(probmatrix[probmatrix[,12+i]>0&!is.na(probmatrix[,12+i]),i])
  compare2[i,2] <- sum(probmatrix[probmatrix[,12+i]>0&!is.na(probmatrix[,12+i]),i+6])
}

1-pchisq(sum((compare2[,2]-compare2[,1])^2/compare2[,2]),4)

out <- rbind(compare,compare2)


out2 <- matrix(NA,19,3)
out2[1:12,2:3] <- out[1:12,1:2]
out2[14:19,2:3] <- out[13:18,1:2]
out2[1:12,1] <- paste(rep(2004:2009,each=2),rep(c("age<8","age>8"),6),sep=",")
out2[14:19,1] <- 2004:2009

write.csv(out2,"TableS10.csv")



