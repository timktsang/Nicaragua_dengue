####
## try to see the time between infection


load("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/MCMC_result_scenario2.Rdata")



u1 <- tt[[12]][1001:11000,]
s1 <- tt[[13]][1001:11000,]

# record the probability of the year of length
# 1: A-A, 2:A-s within study, 3,4 overall

result1 <- matrix(NA,10000,15)
result2 <- matrix(NA,10000,15)
result3 <- matrix(NA,10000,15)
result4 <- matrix(NA,10000,15)

result5 <- matrix(NA,10000,4)
result6 <- matrix(NA,10000,4)

aaaaa1 <- Sys.time()
for (jj in 1:10000){
u2 <- u1[jj,]
u3 <- matrix(as.matrix(u2),ncol=4,byrow=T)
s2 <- s1[jj,]
s3 <- matrix(as.matrix(s2),ncol=4,byrow=T)
## need to compute the distribution for within study year and all years
u3 <- cbind(data1[,c(3)],1*(rowSums(data1[,11:14]!=0)==0),u3,s3)

# col1: year1 age, col2 naive or not

## create matrix to record the infection time interval
u3 <- u3[rowSums(u3[,3:6]!=0)>=2,]
u3[u3[,3]==0,3] <- 999
u3[u3[,4]==0,4] <- 999
u3[u3[,5]==0,5] <- 999
u3[u3[,6]==0,6] <- 999

# need to sort the order of infection as well as their symptom
for (i in 1:nrow(u3)){
temporder <- order(u3[i,3:6])
u3[i,3:6] <- u3[i,temporder+2]
u3[i,7:10] <- u3[i,temporder+6]  
}
# 1: length, 2:3 the symptom of the two infection, 4: within study or not
int1 <- cbind(  u3[,4]-u3[,3],u3[,7],u3[,8],1*(u3[,3]>=u3[,1]))
int2 <- cbind(  u3[,5]-u3[,4],u3[,8],u3[,9],1*(u3[,4]>=u3[,1]))
int3 <- cbind(  u3[,6]-u3[,5],u3[,9],u3[,10],1*(u3[,5]>=u3[,1]))
int2 <- int2[u3[,5]!=999,]
int3 <- int3[u3[,6]!=999,]

temp2 <- rbind( cbind(int1,1),cbind(int2,0))
#temp2 <- int1
for (k in 1:15){
result3[jj,k] <- sum(temp2[temp2[,2]==0&temp2[,3]==0,1]==k)  / length(temp2[temp2[,2]==0&temp2[,3]==0,1])
result4[jj,k] <- sum(temp2[temp2[,2]==0&temp2[,3]==1,1]==k)  / length(temp2[temp2[,2]==0&temp2[,3]==1,1])
result1[jj,k] <- sum(temp2[temp2[,2]==0&temp2[,3]==0&temp2[,4]==1,1]==k)  / length(temp2[temp2[,2]==0&temp2[,3]==0&temp2[,4]==1,1])
result2[jj,k] <- sum(temp2[temp2[,2]==0&temp2[,3]==1&temp2[,4]==1,1]==k)  / length(temp2[temp2[,2]==0&temp2[,3]==1&temp2[,4]==1,1])
}

result5[jj,1] <- mean(temp2[temp2[,2]==0&temp2[,3]==0&temp2[,4]==1,1])
result6[jj,1] <- sd(temp2[temp2[,2]==0&temp2[,3]==0&temp2[,4]==1,1])/sqrt(length(temp2[temp2[,2]==0&temp2[,3]==0&temp2[,4]==1,1]))

result5[jj,2] <- mean(temp2[temp2[,2]==0&temp2[,3]==1&temp2[,4]==1,1])
result6[jj,2] <- sd(temp2[temp2[,2]==0&temp2[,3]==1&temp2[,4]==1,1])/sqrt(length(temp2[temp2[,2]==0&temp2[,3]==1&temp2[,4]==1,1]))

result5[jj,3] <- mean(temp2[temp2[,2]==0&temp2[,3]==0,1])
result6[jj,3] <- sd(temp2[temp2[,2]==0&temp2[,3]==0,1])/sqrt(length(temp2[temp2[,2]==0&temp2[,3]==0,1]))

result5[jj,4] <- mean(temp2[temp2[,2]==0&temp2[,3]==1,1])
result6[jj,4] <- sd(temp2[temp2[,2]==0&temp2[,3]==1,1])/sqrt(length(temp2[temp2[,2]==0&temp2[,3]==1,1]))



}


aaaaa2 <- Sys.time()
print(aaaaa2-aaaaa1)

####





########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}

p1 <- para_summary(result1,4,3,0)
p2 <- para_summary(result2,4,3,0)
p3 <- para_summary(result3,4,3,0)
p4 <- para_summary(result4,4,3,0)



pdf("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/figure4.pdf",width=8, height=3.5)
layout(matrix( 1:2, ncol=2,byrow=T))

par(mar=c(4,5,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,5), ylim=c(0,0.5),type="n")

axis(1,at=c(-1,1:5-0.5,6),labels=c(NA,1:5,NA))
axis(2,at=0:5*0.1,las=1, pos=-0.05)

randset <- sample(1:10000,1000)
for (i in 1:1000){
lines(1:5-0.5,result1[randset[i],1:5],col=rgb(1,0,0,0.01))
lines(1:5-0.5,result2[randset[i],1:5],col=rgb(0,0,1,0.01))
}



mtext("A",side=3,at=0,cex=1.5)
mtext("Probability",side=2,line=2.5)
mtext("Years",side=1,line=2.5)



par(mar=c(4,5,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,15), ylim=c(0,0.3),type="n")

axis(1,at=c(-1,1:15-0.5,16),labels=c(NA,1:15,NA))
axis(2,at=0:3*0.1,las=1, pos=-0.05)

randset <- sample(1:10000,1000)
for (i in 1:1000){
  lines(1:15-0.5,result3[randset[i],],col=rgb(1,0,0,0.01))
  lines(1:15-0.5,result4[randset[i],],col=rgb(0,0,1,0.01))
}



mtext("B",side=3,at=0,cex=1.5)
mtext("Years",side=1,line=2.5)

legend(2,0.3,c("inapparent-to-inapparent","inapparent-to-symptomatic"),cex=0.8,col=c("red","blue"),lty=1,bty="n")



dev.off()



quantile(rowSums(t(t(result1)*1:15)),c(0.5,0.025,0.975))
quantile(rowSums(t(t(result2)*1:15)),c(0.5,0.025,0.975))
quantile(rowSums(t(t(result3)*1:15)),c(0.5,0.025,0.975))
quantile(rowSums(t(t(result4)*1:15)),c(0.5,0.025,0.975))

mean(result5[,1]) 
sd(result5[,1])+mean(result6[,1])

result2 <- matrix(NA,4,3)
for (i in 1:4){
result2[i,1] <- mean(result5[,i]) 
result2[i,2] <- mean(result5[,i]) - 1.96*(sd(result5[,i])+mean(result6[,i])) 
result2[i,3] <- mean(result5[,i]) + 1.96*(sd(result5[,i])+mean(result6[,i])) 
}