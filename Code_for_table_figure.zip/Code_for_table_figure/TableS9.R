
########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}

load("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/goodness_of_fit.Rdata")

t2 <- round(para_summary(compare2,4,3,1)*100,2)

t3 <- cbind(paste(round(compare*100,2),"%",sep="") ,paste(t2[,1],"%",sep=""),paste(t2[,2],"%",sep=""),paste(t2[,3],"%",sep=""))

write.table(t3[7:12,],"/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/TableS9.csv",row.names = F, col.names = F,sep = ",")

