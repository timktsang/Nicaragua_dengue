
## read the ture value
int_para <-  c(rep(0,4),c(0.02,0.05,0.02,0.02,0.02,0.02,0.06,0.02,0.02,0.02,0.03),
               rep(0,4),c(0.02,0.02,0.02,0.04,0.02,0.08,0.07,0.05,0.07,0.02,0.02),
               rep(0,4),c(0.04,0.02,0.03,0.06,0.06,0.02,0.03,0.07,0.04,0.02,0.11),
               rep(0,4),c(0.02,0.02,0.04,0.02,0.02,0.07,0.02,0.06,0.02,0.02,0.07)
               ,c(1,1.5,0.5,0.4,-0.5),0
               ,c(0.3,0.2,0.4,0.1),c(-0.5,-1,-0.1,-0.2),0,0,c(0.1))
print(int_para)
print(int_para)

nsim <- 100


readresult <- function(link){
  
  setwd(paste("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/",link,sep=""))
  
  temp <- list.files(pattern="*.csv")
  counter <- 1
  result <- list(NA)
  for (i in 1:length(temp)){
    if (grepl("summary",temp[i])){
      a1 <- read.csv(temp[i])
      
      result[[counter]] <- a1
      counter <- counter+1
    }
  }
  
  return(result)
}

r1 <- readresult("1serotype_v16")
r2 <- readresult("2serotype_v16")
r3 <- readresult("4serotype_v16")




pdf("FigureS3.pdf",width=9, height=16)
layout(matrix( 1:8, ncol=2,byrow=T))

################################################################################################################################
# panel A for serotype 1

risktable1 <- matrix(NA,nsim,11)
risktable2 <- matrix(NA,nsim,11)
risktable3 <- matrix(NA,nsim,11)
for (i in 1:nsim){
  risktable1[i,] <- r1[[i]][5:15,2]  
  risktable2[i,] <- r2[[i]][5:15,2]  
  risktable3[i,] <- r3[[i]][5:15,2]  
}

plottable <- matrix(NA,11,9)
for (i in 1:11){
  plottable[i,1:3] <- quantile(risktable1[,i],c(0.5,0.025,0.975))  
  plottable[i,1:3+3] <- quantile(risktable2[,i],c(0.5,0.025,0.975))  
  plottable[i,1:3+6] <- quantile(risktable3[,i],c(0.5,0.025,0.975))  
}

zz <- round(max(plottable),2)
zz <- 0.24

par(mar=c(4,5,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0.8,12), ylim=c(0,zz),type="n")

axis(1,at=c(1:11),labels=c(1:11-5),cex.axis=1)
axis(2,at=0:(zz*25)/25, las=1, pos=0.55)

points(1:11-0.3,int_para[5:15],pch=15)
points(1:11-0.1,plottable[,1],pch=16,col="red")
points(1:11+0.1,plottable[,4],pch=17,col="blue")
points(1:11+0.3,plottable[,7],pch=18,col="green")

for (i in 1:11){
  lines(rep(i-0.1,2),plottable[i,2:3],col="red")
  lines(rep(i+0.1,2),plottable[i,2:3+3],col="blue")	
  lines(rep(i+0.3,2),plottable[i,2:3+6],col="green")	
}

mtext("Infection probability",side=2,line=3)
mtext("Year",side=1,line=3)

legend(1,0.24,c("True value","sampling by 1 serotype","sampling by 2 serotype","sampling by 4 serotype"),pch=15:18,cex=0.9,col=c("black","red","blue","green"))

title(main="A", adj=0)

mtext("DENV-1",side=3,line=-0.4)

################################################################################################################################
# panel B for serotype 2

risktable1 <- matrix(NA,nsim,11)
risktable2 <- matrix(NA,nsim,11)
risktable3 <- matrix(NA,nsim,11)
for (i in 1:nsim){
  risktable1[i,] <- r1[[i]][5:15+15,2]  
  risktable2[i,] <- r2[[i]][5:15+15,2]  
  risktable3[i,] <- r3[[i]][5:15+15,2]  
}

plottable <- matrix(NA,11,9)
for (i in 1:11){
  plottable[i,1:3] <- quantile(risktable1[,i],c(0.5,0.025,0.975))  
  plottable[i,1:3+3] <- quantile(risktable2[,i],c(0.5,0.025,0.975))  
  plottable[i,1:3+6] <- quantile(risktable3[,i],c(0.5,0.025,0.975))  
}


zz <- round(max(plottable),2) 

par(mar=c(4,5,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0.8,12), ylim=c(0,zz),type="n")

axis(1,at=c(1:11),labels=c(1:11-5),cex.axis=1)
axis(2,at=0:(zz*50)/50, las=1, pos=0.55)

points(1:11-0.3,int_para[5:15+15],pch=15)
points(1:11-0.1,plottable[,1],pch=16,col="red")
points(1:11+0.1,plottable[,4],pch=17,col="blue")
points(1:11+0.3,plottable[,7],pch=18,col="green")

for (i in 1:11){
  lines(rep(i-0.1,2),plottable[i,2:3],col="red")
  lines(rep(i+0.1,2),plottable[i,2:3+3],col="blue")	
  lines(rep(i+0.3,2),plottable[i,2:3+6],col="green")	
}

mtext("Infection probability",side=2,line=3)
mtext("Year",side=1,line=3)

title(main="B", adj=0)

mtext("DENV-2",side=3,line=-0.4)

################################################################################################################################
# panel C for serotype 3

risktable1 <- matrix(NA,nsim,11)
risktable2 <- matrix(NA,nsim,11)
risktable3 <- matrix(NA,nsim,11)
for (i in 1:nsim){
  risktable1[i,] <- r1[[i]][5:15+30,2]  
  risktable2[i,] <- r2[[i]][5:15+30,2]  
  risktable3[i,] <- r3[[i]][5:15+30,2]  
}

plottable <- matrix(NA,11,9)
for (i in 1:11){
  plottable[i,1:3] <- quantile(risktable1[,i],c(0.5,0.025,0.975))  
  plottable[i,1:3+3] <- quantile(risktable2[,i],c(0.5,0.025,0.975))  
  plottable[i,1:3+6] <- quantile(risktable3[,i],c(0.5,0.025,0.975))  
}


zz <- round(max(plottable),2)
zz <- 0.2

par(mar=c(4,5,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0.8,12), ylim=c(0,zz),type="n")

axis(1,at=c(1:11),labels=c(1:11-5),cex.axis=1)
axis(2,at=0:(zz*25)/25, las=1, pos=0.55)

points(1:11-0.3,int_para[5:15+30],pch=15)
points(1:11-0.1,plottable[,1],pch=16,col="red")
points(1:11+0.1,plottable[,4],pch=17,col="blue")
points(1:11+0.3,plottable[,7],pch=18,col="green")

for (i in 1:11){
  lines(rep(i-0.1,2),plottable[i,2:3],col="red")
  lines(rep(i+0.1,2),plottable[i,2:3+3],col="blue")	
  lines(rep(i+0.3,2),plottable[i,2:3+6],col="green")	
}

mtext("Infection probability",side=2,line=3)
mtext("Year",side=1,line=3)

title(main="C", adj=0)

mtext("DENV-3",side=3,line=-0.4)

################################################################################################################################
# panel D for serotype 4

risktable1 <- matrix(NA,nsim,11)
risktable2 <- matrix(NA,nsim,11)
risktable3 <- matrix(NA,nsim,11)
for (i in 1:nsim){
  risktable1[i,] <- r1[[i]][5:15+45,2]  
  risktable2[i,] <- r2[[i]][5:15+45,2]  
  risktable3[i,] <- r3[[i]][5:15+45,2]  
}

plottable <- matrix(NA,11,9)
for (i in 1:11){
  plottable[i,1:3] <- quantile(risktable1[,i],c(0.5,0.025,0.975))  
  plottable[i,1:3+3] <- quantile(risktable2[,i],c(0.5,0.025,0.975))  
  plottable[i,1:3+6] <- quantile(risktable3[,i],c(0.5,0.025,0.975))  
}


zz <- round(max(plottable),2)  + 0.01

par(mar=c(4,5,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0.8,12), ylim=c(0,zz),type="n")

axis(1,at=c(1:11),labels=c(1:11-5),cex.axis=1)
axis(2,at=0:(zz*50)/50, las=1, pos=0.55)

points(1:11-0.3,int_para[5:15+45],pch=15)
points(1:11-0.1,plottable[,1],pch=16,col="red")
points(1:11+0.1,plottable[,4],pch=17,col="blue")
points(1:11+0.3,plottable[,7],pch=18,col="green")

for (i in 1:11){
  lines(rep(i-0.1,2),plottable[i,2:3],col="red")
  lines(rep(i+0.1,2),plottable[i,2:3+3],col="blue")	
  lines(rep(i+0.3,2),plottable[i,2:3+6],col="green")	
}

mtext("Infection probability",side=2,line=3)
mtext("Year",side=1,line=3)

title(main="D", adj=0)

mtext("DENV-4",side=3,line=-0.4)

################################################################################################################################
# panel E for covariate

risktable1 <- matrix(NA,nsim,5)
risktable2 <- matrix(NA,nsim,5)
risktable3 <- matrix(NA,nsim,5)
for (i in 1:nsim){
  risktable1[i,] <- r1[[i]][61:65,2]  
  risktable2[i,] <- r2[[i]][61:65,2]  
  risktable3[i,] <- r3[[i]][61:65,2]  
}

plottable <- matrix(NA,5,9)
for (i in 1:5){
  plottable[i,1:3] <- quantile(risktable1[,i],c(0.5,0.025,0.975))  
  plottable[i,1:3+3] <- quantile(risktable2[,i],c(0.5,0.025,0.975))  
  plottable[i,1:3+6] <- quantile(risktable3[,i],c(0.5,0.025,0.975))  
}


par(mar=c(4,5,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0.8,6), ylim=c(-1,2),type="n")

axis(1,at=c(1:5),labels=c(1:5),cex.axis=1)
axis(2,at=(-2:4)/2, las=1, pos=0.55)

points(1:5-0.3,int_para[61:65],pch=15)
points(1:5-0.1,plottable[,1],pch=16,col="red")
points(1:5+0.1,plottable[,4],pch=17,col="blue")
points(1:5+0.3,plottable[,7],pch=18,col="green")

for (i in 1:5){
  lines(rep(i-0.1,2),plottable[i,2:3],col="red")
  lines(rep(i+0.1,2),plottable[i,2:3+3],col="blue")	
  lines(rep(i+0.3,2),plottable[i,2:3+6],col="green")	
}

mtext("Beta",side=2,line=3)
mtext("Covariate",side=1,line=3)

title(main="E", adj=0)


mtext("Covariate effect on infection",side=3,line=-0.4)

################################################################################################################################
# panel F for symptom

risktable1 <- matrix(NA,nsim,4)
risktable2 <- matrix(NA,nsim,4)
risktable3 <- matrix(NA,nsim,4)
for (i in 1:nsim){
  risktable1[i,] <- r1[[i]][67:70,2]  
  risktable2[i,] <- r2[[i]][67:70,2]  
  risktable3[i,] <- r3[[i]][67:70,2]  
}

plottable <- matrix(NA,4,9)
for (i in 1:4){
  plottable[i,1:3] <- quantile(risktable1[,i],c(0.5,0.025,0.975))  
  plottable[i,1:3+3] <- quantile(risktable2[,i],c(0.5,0.025,0.975))  
  plottable[i,1:3+6] <- quantile(risktable3[,i],c(0.5,0.025,0.975))  
}


par(mar=c(4,5,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0.8,5), ylim=c(0,0.5),type="n")

axis(1,at=c(1:4),labels=c(1:4),cex.axis=1)
axis(2,at=0:5/10, las=1, pos=0.55)

points(1:4-0.3,int_para[67:70],pch=15)
points(1:4-0.1,plottable[,1],pch=16,col="red")
points(1:4+0.1,plottable[,4],pch=17,col="blue")
points(1:4+0.3,plottable[,7],pch=18,col="green")

for (i in 1:4){
  lines(rep(i-0.1,2),plottable[i,2:3],col="red")
  lines(rep(i+0.1,2),plottable[i,2:3+3],col="blue")	
  lines(rep(i+0.3,2),plottable[i,2:3+6],col="green")	
}

mtext("Probability",side=2,line=3)
mtext("Serotype",side=1,line=3)

title(main="F", adj=0)


mtext("Disease probability given infection",side=3,line=-0.4)

################################################################################################################################
# panel G for symptom covariate

risktable1 <- matrix(NA,nsim,4)
risktable2 <- matrix(NA,nsim,4)
risktable3 <- matrix(NA,nsim,4)
for (i in 1:nsim){
  risktable1[i,] <- r1[[i]][71:74,2]  
  risktable2[i,] <- r2[[i]][71:74,2]  
  risktable3[i,] <- r3[[i]][71:74,2]  
}

plottable <- matrix(NA,4,9)
for (i in 1:4){
  plottable[i,1:3] <- quantile(risktable1[,i],c(0.5,0.025,0.975))  
  plottable[i,1:3+3] <- quantile(risktable2[,i],c(0.5,0.025,0.975))  
  plottable[i,1:3+6] <- quantile(risktable3[,i],c(0.5,0.025,0.975))  
}


par(mar=c(4,5,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0.8,5), ylim=c(-2,0.5),type="n")

axis(1,at=c(1:4),labels=c(1:4),cex.axis=1)
axis(2,at=(-4:1)/2, las=1, pos=0.55)

points(1:4-0.3,int_para[71:74],pch=15)
points(1:4-0.1,plottable[,1],pch=16,col="red")
points(1:4+0.1,plottable[,4],pch=17,col="blue")
points(1:4+0.3,plottable[,7],pch=18,col="green")

for (i in 1:4){
  lines(rep(i-0.1,2),plottable[i,2:3],col="red")
  lines(rep(i+0.1,2),plottable[i,2:3+3],col="blue")	
  lines(rep(i+0.3,2),plottable[i,2:3+6],col="green")	
}

mtext("Beta",side=2,line=3)
mtext("Covariate",side=1,line=3)

title(main="G", adj=0)


mtext("Covariate effect on disease",side=3,line=-0.4)

dev.off()
