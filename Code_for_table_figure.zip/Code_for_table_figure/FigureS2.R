
########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}

tempenv1 <- new.env()
tempenv2 <- new.env()
tempenv3 <- new.env()

load("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/MCMC_result_scenario1.Rdata", envir=tempenv1)
load("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/MCMC_result_scenario2.Rdata", envir=tempenv2)
load("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/MCMC_result_scenario3.Rdata", envir=tempenv3)

a1 <- tempenv1$tt[[1]][1001:11000,]
a2 <- tempenv2$tt[[1]][1001:11000,]
a3 <- tempenv3$tt[[1]][1001:11000,]

a1[,1:60] <- a1[,1:60]*exp(a1[,rep(68,60)])*exp(a1[,rep(69,60)])
a2[,1:60] <- a2[,1:60]*exp(a2[,rep(68,60)])*exp(a2[,rep(69,60)])
a3[,1:60] <- a3[,1:60]*exp(a3[,rep(68,60)])*exp(a3[,rep(69,60)])

p1 <- para_summary(a1,4,3,0)
p2 <- para_summary(a2,4,3,0)
p3 <- para_summary(a3,4,3,0)


pdf("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/FigureS2.pdf",width=12, height=16)
layout(matrix( 1:4, ncol=1,byrow=T))

## 4 panel with 4 serotype, list the estimate from the three scanerios together 
############



plottable1 <- p1[1:15,1:3]

plottable2 <- p2[1:15,1:3]

plottable3 <- p3[1:15,1:3]


zz <- round(max(cbind(plottable1,plottable2,plottable3)),2)

cexpara <- 1.3

par(mar=c(4,5,1,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0.8,16), ylim=c(0,0.12),type="n")

axis(1,at=c(1:15),labels=1995+0:14,cex.axis=1)
axis(2,at=0:4*3/100, las=1, pos=0.55)

points(1:15-0.21,plottable1[,1],pch=16,col="black",cex=cexpara)
points(1:15-0.07,plottable2[,1],pch=16,col="red",cex=cexpara)
points(1:15+0.07,plottable3[,1],pch=16,col="blue",cex=cexpara)

for (i in 1:15){
  lines(rep(i,2)-0.21,plottable1[i,2:3],col="black")
  lines(rep(i,2)-0.07,plottable2[i,2:3],col="red")
  lines(rep(i,2)+0.07,plottable3[i,2:3],col="blue")
}


legend(2,0.12,c("Scenario 1","Scenario 2","Scenario 3"),pch=16,cex=0.9,col=c("black","red","blue"),lty=1)


mtext("Infection probability",side=2,line=3)

title(main="A", adj=0)

################################################################################################################################################


plottable1 <- p1[1:15+15,1:3]

plottable2 <- p2[1:15+15,1:3]

plottable3 <- p3[1:15+15,1:3]


zz <- round(max(cbind(plottable1,plottable2,plottable3)),2)

cexpara <- 1.3

par(mar=c(4,5,1,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0.8,16), ylim=c(0,0.27),type="n")

axis(1,at=c(1:15),labels=1995+0:14,cex.axis=1)
axis(2,at=0:9*3/100, las=1, pos=0.55)

points(1:15-0.21,plottable1[,1],pch=16,col="black",cex=cexpara)
points(1:15-0.07,plottable2[,1],pch=16,col="red",cex=cexpara)
points(1:15+0.07,plottable3[,1],pch=16,col="blue",cex=cexpara)

for (i in 1:15){
  lines(rep(i,2)-0.21,plottable1[i,2:3],col="black")
  lines(rep(i,2)-0.07,plottable2[i,2:3],col="red")
  lines(rep(i,2)+0.07,plottable3[i,2:3],col="blue")
}



mtext("Infection probability",side=2,line=3)

title(main="B", adj=0)

################################################################################################################################################


plottable1 <- p1[1:15+30,1:3]

plottable2 <- p2[1:15+30,1:3]

plottable3 <- p3[1:15+30,1:3]


zz <- round(max(cbind(plottable1,plottable2,plottable3)),2)

cexpara <- 1.3

par(mar=c(4,5,1,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0.8,16), ylim=c(0,0.33),type="n")

axis(1,at=c(1:15),labels=1995+0:14,cex.axis=1)
axis(2,at=0:11*3/100, las=1, pos=0.55)

points(1:15-0.21,plottable1[,1],pch=16,col="black",cex=cexpara)
points(1:15-0.07,plottable2[,1],pch=16,col="red",cex=cexpara)
points(1:15+0.07,plottable3[,1],pch=16,col="blue",cex=cexpara)

for (i in 1:15){
  lines(rep(i,2)-0.21,plottable1[i,2:3],col="black")
  lines(rep(i,2)-0.07,plottable2[i,2:3],col="red")
  lines(rep(i,2)+0.07,plottable3[i,2:3],col="blue")
}



mtext("Infection probability",side=2,line=3)

title(main="C", adj=0)

################################################################################################################################################


plottable1 <- p1[1:15+45,1:3]

plottable2 <- p2[1:15+45,1:3]

plottable3 <- p3[1:15+45,1:3]


zz <- round(max(cbind(plottable1,plottable2,plottable3)),2)

cexpara <- 1.3

par(mar=c(4,5,1,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0.8,16), ylim=c(0,zz),type="n")

axis(1,at=c(1:15),labels=1995+0:14,cex.axis=1)
axis(2,at=0:(zz*100)/100, las=1, pos=0.55)

points(1:15-0.21,plottable1[,1],pch=16,col="black",cex=cexpara)
points(1:15-0.07,plottable2[,1],pch=16,col="red",cex=cexpara)
points(1:15+0.07,plottable3[,1],pch=16,col="blue",cex=cexpara)

for (i in 1:15){
  lines(rep(i,2)-0.21,plottable1[i,2:3],col="black")
  lines(rep(i,2)-0.07,plottable2[i,2:3],col="red")
  lines(rep(i,2)+0.07,plottable3[i,2:3],col="blue")
}



mtext("Infection probability",side=2,line=3)

title(main="D", adj=0)

################################################################################################################################################



dev.off()










