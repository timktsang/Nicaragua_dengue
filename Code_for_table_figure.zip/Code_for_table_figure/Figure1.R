

load("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/MCMC_result_scenario2.Rdata")

temp1 <- tt[[1]][,1:60]*exp(tt[[1]][,rep(68,60)])*exp(tt[[1]][,rep(70,60)])

r1 <- list(NA)
r1[[1]] <- cbind(matrix(NA,ncol(temp1),1),para_summary(temp1,4,3,0))



pdf("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/Figure1.pdf",width=12, height=8)
layout(matrix( 1:2, ncol=1,byrow=T))

u <- 1
################################################################################################################################
# panel A for serotype 1

plottable1 <- r1[[u]][1:15,2:4]

plottable2 <- r1[[u]][1:15+15,2:4]

plottable3 <- r1[[u]][1:15+30,2:4]

plottable4 <- r1[[u]][1:15+45,2:4]

zz <- round(max(cbind(plottable1,plottable2,plottable3,plottable4)),2)

cexpara <- 1.3

par(mar=c(4,5,2,1))
zz <- 0.35
plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0.8,16), ylim=c(0,zz),type="n")

axis(1,at=c(1:15),labels=1995+0:14,cex.axis=1)
axis(2,at=0:7*5/100, las=1, pos=0.55,cex.axis=1.5)

points(1:15-0.21,plottable1[,1],pch=16,col="black",cex=cexpara)
points(1:15-0.07,plottable2[,1],pch=16,col="red",cex=cexpara)
points(1:15+0.07,plottable3[,1],pch=16,col="blue",cex=cexpara)
points(1:15+0.21,plottable4[,1],pch=16,col="green",cex=cexpara)

for (i in 1:15){
  lines(rep(i,2)-0.21,plottable1[i,2:3],col="black")
  lines(rep(i,2)-0.07,plottable2[i,2:3],col="red")
  lines(rep(i,2)+0.07,plottable3[i,2:3],col="blue")
  lines(rep(i,2)+0.21,plottable4[i,2:3],col="green")
}


mtext("A",side=3,line=0.5,cex=2,at=0)

legend(13.5,0.38,c("DENV-1","DENV-2","DENV-3","DENV-4"),pch=16,cex=1.5,col=c("black","red","blue","green"),lty=1,bty="n")


mtext("Infection probability",side=2,line=3,cex=1.5)


mtext("Estimated infection probability",side=3,line=0,cex=1.5)

### panel B

sur <- data2


plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0.8,16), ylim=c(0,6000),type="n")

axis(1,at=c(1:15),labels=1995+0:14,cex.axis=1)
axis(2,at=0:6*1000, las=1, pos=0.55,cex.axis=1.5)

lines(1:15,sur[1,],col="black")
lines(1:15,sur[2,],col="red")
lines(1:15,sur[3,],col="blue")
lines(1:15,sur[4,],col="green")

points(1:15,sur[1,],col="black",pch=16,cex=cexpara)
points(1:15,sur[2,],col="red",pch=16,cex=cexpara)
points(1:15,sur[3,],col="blue",pch=16,cex=cexpara)
points(1:15,sur[4,],col="green",pch=16,cex=cexpara)

mtext("Count",side=2,line=3,cex=1.5)
mtext("Year",side=1,line=3,cex=1.5)

mtext("B",side=3,line=1,cex=2,at=0)

mtext("Number of surveillance cases",side=3,line=1,cex=1.5)

dev.off()



