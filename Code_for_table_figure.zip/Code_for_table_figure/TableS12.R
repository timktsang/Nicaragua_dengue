data <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/data/2017_05_22.csv")

data1 <- data[,1:5]
# naive or not
data1[,6] <- 1*(rowSums(data[,11:14])==0)
data1[,7:12] <- 1*(data[,3:8*5+5]==0)
for (i in 1:6){
data1[data[,(i+2)*5+5]==-1,6+i] <- -1  
}
data1[,13:18] <- data[,54:59]

# remove the 5's 1 to -1
for (i in 1:6){
data1[ rowSums(data[,(i+2)*5+1:5])==5,6+i] <- -1  
}

### count all of the naive and first infection
# create a matrix of all interval
# 1. id
# 2. year
# 3. age
# 4. infeciton or not
# 5. symptom or not
# 6. year since last infection
# 7. number of prior infection, ## if it is unknown it seems it must not be naive?
# 8. if the last infection is symptomatic?
# 9. naive at baseline
# 10. sex
data2 <- matrix(NA,nrow(data1)*6,10)
data2[,1] <- rep(data1$id,each=6)
data2[data2[,1]%in%data1[data1[,6]==1,1],7] <- 0
data2[data2[,1]%in%data1[data1[,6]==0,1],7] <- 1
data2[,9] <- rep(data1[,6],each=6)
data2[,10] <- rep(data1[,4],each=6)

for (i in 1:nrow(data)){ # i is observation
for (j in 1:6){  # j is year
data2[(i-1)*6+j,2] <- j
data2[(i-1)*6+j,3] <- data1[i,]$age+j-data1[i,]$first_year
data2[(i-1)*6+j,4] <- data1[i,6+j]
data2[(i-1)*6+j,5] <- data1[i,12+j]
# input the year since infection
if ((data2[(i-1)*6+j,4]==1)&&(j!=6)){
data2[(i-1)*6+(j+1):6,6] <- (j+1):6-j
data2[(i-1)*6+(j+1):6,8] <- data2[(i-1)*6+j,5]
data2[(i-1)*6+(j+1):6,7] <- data2[(i-1)*6+j,7]+1 
}
}
}
data2[is.na(data2)] <- -1

table1 <- matrix(NA,80,9)

cond <- list(NA)
# age
cond[[3]] <- data2[,3] <=5
cond[[4]] <- data2[,3] >5 & data2[,3] <=8
cond[[5]] <- data2[,3] >8
# sex
cond[[7]] <- data2[,10] ==1
cond[[8]] <- data2[,10] ==2
# number of prior infection
cond[[10]] <- data2[,7] ==0
cond[[11]] <- data2[,7] ==1
cond[[12]] <- data2[,7] >=2
cond[[13]] <- data2[,7] >=1
# Year since last infection
cond[[15]] <- data2[,6] ==1
cond[[16]] <- data2[,6] ==2
cond[[17]] <- data2[,6] >=3
# number of prior infection times year since last infection
cond[[19]] <- data2[,7] ==1 & data2[,6]==1
cond[[20]] <- data2[,7] ==1 & data2[,6]==2
cond[[21]] <- data2[,7] ==1 & data2[,6]>2
cond[[22]] <- data2[,7] >1 & data2[,6]==1
cond[[23]] <- data2[,7] >1 & data2[,6]==2
cond[[24]] <- data2[,7] >1 & data2[,6]>2
cond[[25]] <- data2[,7] >=1 & data2[,6]==1
cond[[26]] <- data2[,7] >=1 & data2[,6]==2
cond[[27]] <- data2[,7] >=1 & data2[,6]>2

# symptom status of most recent infection
cond[[29]] <- data2[,8] ==1
cond[[30]] <- data2[,8] ==0

# age, number of prior infection
cond[[32]] <- data2[,3] <=5 & data2[,7] ==0
cond[[33]] <- data2[,3] >5 & data2[,3] <=8 & data2[,7] ==0
cond[[34]] <- data2[,3] >8 & data2[,7] ==0
cond[[35]] <- data2[,3] <=5 & data2[,7] ==1
cond[[36]] <- data2[,3] >5 & data2[,3] <=8 & data2[,7] ==1
cond[[37]] <- data2[,3] >8 & data2[,7] ==1
cond[[38]] <- data2[,3] <=5 & data2[,7] >1
cond[[39]] <- data2[,3] >5 & data2[,3] <=8 & data2[,7] >1
cond[[40]] <- data2[,3] >8 & data2[,7] >1

# age, years since last infection
cond[[42]] <- data2[,3] <=5 & data2[,6] ==1
cond[[43]] <- data2[,3] >5 & data2[,3] <=8 & data2[,6] ==1
cond[[44]] <- data2[,3] >8 & data2[,6] ==1
cond[[45]] <- data2[,3] <=5 & data2[,6] ==2
cond[[46]] <- data2[,3] >5 & data2[,3] <=8 & data2[,6] ==2
cond[[47]] <- data2[,3] >8 & data2[,6] ==2
cond[[48]] <- data2[,3] <=5 & data2[,6] >2
cond[[49]] <- data2[,3] >5 & data2[,3] <=8 & data2[,6] >2
cond[[50]] <- data2[,3] >8 & data2[,6] >2

# + age
# number of prior infection times year since last infection
cond[[52]] <- data2[,7] ==1 & data2[,6]==1 & data2[,3] <=5
cond[[53]] <- data2[,7] ==1 & data2[,6]==2 & data2[,3] <=5
cond[[54]] <- data2[,7] ==1 & data2[,6]>2 & data2[,3] <=5
cond[[55]] <- data2[,7] >1 & data2[,6]==1 & data2[,3] <=5
cond[[56]] <- data2[,7] >1 & data2[,6]==2 & data2[,3] <=5
cond[[57]] <- data2[,7] >1 & data2[,6]>2 & data2[,3] <=5
cond[[58]] <- data2[,7] >=1 & data2[,6]==1 & data2[,3] <=5
cond[[59]] <- data2[,7] >=1 & data2[,6]==2 & data2[,3] <=5
cond[[60]] <- data2[,7] >=1 & data2[,6]>2 & data2[,3] <=5

cond[[62]] <- data2[,7] ==1 & data2[,6]==1 & data2[,3] >=6 & data2[,3] <=8
cond[[63]] <- data2[,7] ==1 & data2[,6]==2 & data2[,3] >=6 & data2[,3] <=8
cond[[64]] <- data2[,7] ==1 & data2[,6]>2 & data2[,3] >=6 & data2[,3] <=8
cond[[65]] <- data2[,7] >1 & data2[,6]==1 & data2[,3] >=6 & data2[,3] <=8
cond[[66]] <- data2[,7] >1 & data2[,6]==2 & data2[,3] >=6 & data2[,3] <=8
cond[[67]] <- data2[,7] >1 & data2[,6]>2 & data2[,3] >=6 & data2[,3] <=8
cond[[68]] <- data2[,7] >=1 & data2[,6]==1 & data2[,3] >=6 & data2[,3] <=8
cond[[69]] <- data2[,7] >=1 & data2[,6]==2 & data2[,3] >=6 & data2[,3] <=8
cond[[70]] <- data2[,7] >=1 & data2[,6]>2 & data2[,3] >=6 & data2[,3] <=8

cond[[72]] <- data2[,7] ==1 & data2[,6]==1 & data2[,3] >8
cond[[73]] <- data2[,7] ==1 & data2[,6]==2 & data2[,3] >8
cond[[74]] <- data2[,7] ==1 & data2[,6]>2 & data2[,3] >8
cond[[75]] <- data2[,7] >1 & data2[,6]==1 & data2[,3] >8
cond[[76]] <- data2[,7] >1 & data2[,6]==2 & data2[,3] >8
cond[[77]] <- data2[,7] >1 & data2[,6]>2 & data2[,3] >8
cond[[78]] <- data2[,7] >=1 & data2[,6]==1 & data2[,3] >8
cond[[79]] <- data2[,7] >=1 & data2[,6]==2 & data2[,3] >8
cond[[80]] <- data2[,7] >=1 & data2[,6]>2 & data2[,3] >8

########################################################################################################################
cond[[69]] <- data2[,3] <=8

# age, years since last infection
cond[[42]] <- data2[,3] <=8 & data2[,6] ==1
cond[[45]] <- data2[,3] >8 & data2[,6] ==1
cond[[43]] <- data2[,3] <=8 & data2[,6] ==2
cond[[46]] <- data2[,3] >8 & data2[,6] ==2
cond[[44]] <- data2[,3] <=8 & data2[,6] >2
cond[[47]] <- data2[,3] >8 & data2[,6] >2

# age, number of prior infection
cond[[32]] <-  data2[,3] <=8 & data2[,7] ==0
cond[[33]] <-  data2[,3] <=8 & data2[,7] ==1
cond[[34]] <-  data2[,3] <=8 & data2[,7] >1
cond[[35]] <-  data2[,3] >8 & data2[,7] ==0
cond[[36]] <-  data2[,3] >8 & data2[,7] ==1
cond[[37]] <-  data2[,3] >8 & data2[,7] >1


########################################################################################################################

# total number
table1[1,1] <- sum(data2[,4]==1) 
table1[1,4] <- sum(data2[,4]==1&data2[,9]==1)
table1[1,7] <- sum(data2[,4]==1&data2[,9]==0)
for (i in 2:80){
if (length(cond[[i]])>0){
  table1[i,1] <- sum(cond[[i]] & data2[,4]==1 & data2[,5]==1)
  table1[i,2] <- sum(cond[[i]] & data2[,4]==1)
  table1[i,4] <- sum(cond[[i]] & data2[,4]==1 & data2[,5]==1 & data2[,9]==1)
  table1[i,5] <- sum(cond[[i]] & data2[,4]==1 & data2[,9]==1)
  table1[i,7] <- sum(cond[[i]] & data2[,4]==1 & data2[,5]==1 & data2[,9]==0)
  table1[i,8] <- sum(cond[[i]] & data2[,4]==1 & data2[,9]==0)
}
}

table1[,3] <- round(table1[,1]/table1[,2]*100,1)
table1[,6] <- round(table1[,4]/table1[,5]*100,1)
table1[,9] <- round(table1[,7]/table1[,8]*100,1)

table3 <- matrix(NA,nrow(table1),3)
for (i in 1:3){
table3[,i] <- paste(table1[,3*i-2],"/",table1[,3*i-1]," (",table1[,3*i],"%)",sep="")  
}

table3[grepl("NA",table3)] <- " "
table3[1,] <- table1[1,c(1,4,7)]

table4 <- matrix(" ",37,4)
table4[1,2:4] <- c("All","Dengue-naive","Non dengue-naive")
table4[2:37,1] <- c("Number of person-year","Age"," 2-8"," >8","Sex"," Male"," Female","Number of prior infection"," 0"," 1"," >1","Years since last infection"," 1"," 2",
                    " >2","Age, years since last infection"," 2-8, 1 year"," 2-8, 2 years"," 2-8, >2 years"," >8, 1 year"," >8, 2 years"," >8, >2 years",
                    "Age, Number of prior infection"," 2-8, 0"," 2-8, 1","2-8, >1"," >8, 0"," >8, 1"," >8, >1","Number of prior infection, years since last infection",
                    "1, 1 year","1, 2 years","1, >2 years",">1, 1 year",">1, 2 years",">1, >2 years")

table4[2,2:4] <- table3[1,]
table4[4:8,2:4] <- table3[4:8,]
table4[4,2:4] <- table3[69,]
table4[10:12,2:4] <- table3[10:12,]
table4[10,4] <- " "
table4[14:16,2:4] <- table3[15:17,]
table4[18:23,2:4] <- table3[42:47,]
table4[25:30,2:4] <- table3[32:37,]
table4[32:37,2:4] <- table3[19:24,]
#table4[18:20,4] <- " "

table5 <- table4[c(2,4:5,7:8,10:12,14:16,18:23,25:30,32:37),2:4]
table5[c(6,18,21,24:26),3] <- NA

write.table(table5,"/Users/timtsang/Dropbox2/Dropbox/Nicaragua/version/natcomm/tableS4.csv",row.names = F, col.names = F,sep = ",")

write.table(table5,"/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/TableS12.csv",row.names = F, col.names = F,sep = ",")