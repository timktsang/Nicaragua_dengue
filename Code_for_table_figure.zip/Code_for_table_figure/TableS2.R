
## table 1 is the basic number of infection

data <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/data/2017_05_22.csv")
data1 <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/data/2017_05_22_2.csv")

data1$age <- ceiling(data1$age)

table1 <- matrix(0,10,5)
slist <- list(1,2,3,4,c(5:100))

for (i in 1:6){
for (j in 1:5){  
# number of participant
table1[10,j] <- table1[10,j] + sum(!is.na(data1[,4*i+2])&data1[,4*i+2]==1&data1[,4*i+4]%in%slist[[j]]) 
# confirm by lab test
table1[1,j] <- table1[1,j] + sum(data1[,4*i+5]==1 &!is.na(data1[,4*i+5]) &!is.na(data1[,4*i+2])&data1[,4*i+2]==1&data1[,4*i+4]%in%slist[[j]] )  
table1[2,j] <- table1[2,j] + sum(data1[,4*i+5]==2 &!is.na(data1[,4*i+5]) &!is.na(data1[,4*i+2])&data1[,4*i+2]==1&data1[,4*i+4]%in%slist[[j]] )  
table1[3,j] <- table1[3,j] + sum(data1[,4*i+5]==3 &!is.na(data1[,4*i+5]) &!is.na(data1[,4*i+2])&data1[,4*i+2]==1&data1[,4*i+4]%in%slist[[j]] )  
table1[4,j] <- table1[4,j] + sum(data1[,4*i+5]%in%c(4,5) &!is.na(data1[,4*i+5]) &!is.na(data1[,4*i+2])&data1[,4*i+2]==1&data1[,4*i+4]%in%slist[[j]] )
# Age
table1[5,j] <- table1[5,j] + sum(data1$age+i-data1$first_year<=5 &!is.na(data1[,4*i+2]) &!is.na(data1[,4*i+2])&data1[,4*i+2]==1&data1[,4*i+4]%in%slist[[j]])  
table1[6,j] <- table1[6,j] + sum(data1$age+i-data1$first_year>5&data1$age+i-data1$first_year<=8 &!is.na(data1[,4*i+2]) &!is.na(data1[,4*i+2])&data1[,4*i+2]==1&data1[,4*i+4]%in%slist[[j]]) 
table1[7,j] <- table1[7,j] + sum(data1$age+i-data1$first_year>8 &!is.na(data1[,4*i+2]) &!is.na(data1[,4*i+2])&data1[,4*i+2]==1&data1[,4*i+4]%in%slist[[j]]) 
# Sex
table1[8,j] <- table1[8,j] + sum(data1$sex==1 &!is.na(data1[,4*i+2]) &!is.na(data1[,4*i+2])&data1[,4*i+2]==1&data1[,4*i+4]%in%slist[[j]] )  
table1[9,j] <- table1[9,j] + sum(data1$sex==2 &!is.na(data1[,4*i+2]) &!is.na(data1[,4*i+2])&data1[,4*i+2]==1&data1[,4*i+4]%in%slist[[j]]) 

}}

table2 <- table1
for (i in 1:5){
table2[,i] <- round(table1[,i]/table1[10,i]*100)
}

table11 <- matrix(NA,nrow(table1),5)
for (i in 1:5){
table11[,i] <- paste(table1[,i]," (",table2[,i],")",sep="")  
}
table11[10,] <- table1[10,]

write.table(table11,"/Users/timtsang/Dropbox2/Dropbox/Nicaragua/version/natcomm/tableS2.csv",row.names = F, col.names = F,sep = ",")

write.table(table11,"/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/TableS2.csv",row.names = F, col.names = F,sep = ",")

