
### remark
### _7: scanerio2, 7b: scnaerio1, 7c:scanerio3

########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}

tempenv1 <- new.env()
tempenv2 <- new.env()
tempenv3 <- new.env()

load("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/MCMC_result_scenario2.Rdata", envir=tempenv1)
load("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/MCMC_result_scenario1.Rdata", envir=tempenv2)
load("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/MCMC_result_scenario3.Rdata", envir=tempenv3)



pp1 <- para_summary(tempenv1$tt[[1]][1001:11000,],4,3,0)
pp2 <- para_summary(tempenv2$tt[[1]][1001:11000,],4,3,0)
pp3 <- para_summary(tempenv3$tt[[1]][1001:11000,],4,3,0)

p1 <- para_summary(tempenv1$tt[[1]][1001:11000,],4,3,0)

a1 <- cbind(tempenv1$tt[[1]][1001:11000,c(87,90,88,91,89)]-tempenv1$tt[[1]][1001:11000,c(86,89,86,89,86)])
a2 <- para_summary(a1,4,3,0)
record <- matrix(NA,15,3)
record[1:4,1:3] <- p1[81:84,1:3]
record[5,1:3] <- a2[5,1:3]
record[6:9,1:3] <- a2[1:4,1:3]
record[10,1:3] <- p1[85,1:3]
record[5:10,] <- exp(record[5:10,])

## age effect is row 5
## 6-9 is age <8 y1, age >8 y1, age <8 y2, age >8 y2

plotdata <- record
plotdata[5:9,] <- log2(plotdata[5:9,])


###############
## for sensitivity analysis
### record is the first
record1 <- record

a1 <- cbind(tempenv2$tt[[1]][1001:11000,c(87,90,88,91,89)]-tempenv2$tt[[1]][1001:11000,c(86,89,86,89,86)])
a2 <- para_summary(a1,4,3,0)
record2 <- matrix(NA,15,3)
record2[1:4,1:3] <- pp2[81:84,1:3]
record2[5,1:3] <- a2[5,1:3]
record2[6:9,1:3] <- a2[1:4,1:3]
record2[10,1:3] <- pp2[85,1:3]
record2[5:10,] <- exp(record2[5:10,])

a1 <- cbind(tempenv1$tt[[1]][1001:11000,c(87,90,88,91,89)]-tempenv1$tt[[1]][1001:11000,c(86,89,86,89,86)])
a2 <- para_summary(a1,4,3,0)
record3 <- matrix(NA,15,3)
record3[1:4,1:3] <- pp3[81:84,1:3]
record3[5,1:3] <- a2[5,1:3]
record3[6:9,1:3] <- a2[1:4,1:3]
record3[10,1:3] <- pp3[85,1:3]
record3[5:10,] <- exp(record3[5:10,])



###########




tableform <- function(record2){
output <- paste(record2[,1]," (",record2[,2],", ",record2[,3],")",sep="")

## the order for the plot and the table is diiferent

output2 <- matrix(" ",29,2)
output2[,1] <- c(" ","Serotype"," DENV-1"," DENV-2"," DENV-3"," DENV-4"," "," ","Age"," 2-8"," >8",
                 "Age, Number of prior infection","Age 2-8"," 0"," 1"," >1","Age >8"," 0"," 1"," >1",
                 "Age, years since last infection","Age 2-8"," 1 year"," 2 years"," >2 years","Age >8"," 1 year"," 2 years"," >2 years")

output2[3:6,2] <- output[1:4]
output2[c(11,15,16,19,20,24,25,28,29),2] <- output[5:13]

output2[8,2] <- "Odds ratio"
output2[1,2] <- "Probability"
output2[c(10,14,18,23,27),2] <- "Ref"

return(output2)
}

record1 <- pp1[81:93,]
record2 <- pp2[81:93,]
record3 <- pp3[81:93,]
record1[5:13,] <- exp(record1[5:13,])
record2[5:13,] <- exp(record2[5:13,])
record3[5:13,] <- exp(record3[5:13,])

a1 <- tableform(round(record1,2))
a2 <- tableform(round(record2,2))
a3 <- tableform(round(record3,2))

aa1 <- cbind(a1,a2,a3)

aa1 <- aa1[,c(1,4,2,6)]
aa1 <-  rbind(c(" ","Scanerio 1","Scanerio 2","Scanerio 3"),aa1)

aa2 <- aa1[c(4:7,11:12,24:26,28:30,15:17,19:21),2:4]

write.table(aa2,"/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/TableS6.csv",row.names = F, col.names = F,sep = ",")
