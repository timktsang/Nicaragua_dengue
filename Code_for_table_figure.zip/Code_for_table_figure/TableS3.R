

load("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/MCMC_result_scenario2.Rdata")

temp1 <- tt[[1]][,1:60]*exp(tt[[1]][,rep(68,60)])*exp(tt[[1]][,rep(70,60)])

r1 <- list(NA)
r1[[1]] <- cbind(matrix(NA,ncol(temp1),1),para_summary(temp1,4,3,0))



u <- 1
################################################################################################################################
# panel A for serotype 1

plottable1 <- r1[[u]][1:15,2:4]

plottable2 <- r1[[u]][1:15+15,2:4]

plottable3 <- r1[[u]][1:15+30,2:4]

plottable4 <- r1[[u]][1:15+45,2:4]



p1 <- round(plottable1,3)
p2 <- round(plottable2,3)
p3 <- round(plottable3,3)
p4 <- round(plottable4,3)

output <- matrix(NA,15,5)

output[,1] <- paste(1995:2009,1996:2010,sep="-")
output[,2] <- paste(p1[,1]," (",p1[,2],", ",p1[,3],")",sep="")
output[,3] <- paste(p2[,1]," (",p2[,2],", ",p2[,3],")",sep="")
output[,4] <- paste(p3[,1]," (",p3[,2],", ",p3[,3],")",sep="")
output[,5] <- paste(p4[,1]," (",p4[,2],", ",p4[,3],")",sep="")

output2 <- matrix(" ",16,5)
output2[2:16,] <- output
output2[1,] <- c("Year","DENV-1","DENV-2","DENV-3","DENV-4")


write.table(output2,"/Users/timtsang/Dropbox2/Dropbox/Nicaragua/version/natcomm/tableS5.csv",row.names = F, col.names = F,sep = ",")
write.table(output2,"/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/TableS3.csv",row.names = F, col.names = F,sep = ",")

