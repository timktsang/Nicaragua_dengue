data <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua/data/2017_05_22.csv")

data$ninf <- rowSums(data[,c("y1_5","y2_5","y3_5","y4_5","y5_5","y6_5")] == 0)
data$nyear <- rowSums(data[,c("y1_5","y2_5","y3_5","y4_5","y5_5","y6_5")] != -1)
data$ind <- data$ninf/data$nyear


table1 <- data.frame(matrix(NA,200,7))

data2 <- data

data2$nfano <- data2$nfan
### for those values variable, make them into group
# 0,1-2,3-4,5-6,>7
valuecolumn <- c(66:71,73:78,79:84,90:92,95,97,99,101,103,105)

for (i in valuecolumn){
data2[data2[,i]%in%c(0)&!is.na(data2[,i]),i] <- 0
data2[data2[,i]%in%c(1,2)&!is.na(data2[,i]),i] <- 1
data2[data2[,i]%in%c(3,4)&!is.na(data2[,i]),i] <- 2
data2[data2[,i]%in%c(5,6)&!is.na(data2[,i]),i] <- 3
data2[data2[,i]>=7&!is.na(data2[,i]),i] <- 4
}



############## TRY to make it automatic


computetable <- function(data2,rownumber){
  level <- sort(unique(data2[!is.na(data2[,rownumber]),rownumber]))
  nlevel <- length(level)
  table1 <- matrix(NA,nlevel,7)
  for (i in 1:nlevel){
    table1[i,3] <- sum(data2$ninf[data2[,rownumber]==level[i]&!is.na(data2[,rownumber])])
    table1[i,4] <- sum(data2$nyear[data2[,rownumber]==level[i]&!is.na(data2[,rownumber])])
    table1[i,5] <- table1[i,3]/table1[i,4]*100
  }
  table1[1,6] <- cor(data2$ind,data2[,rownumber], use="complete.obs")
  table1[1,7] <- cor.test(data2$ind,data2[,rownumber], use="complete.obs")$p.value
  return(table1)
}


#################################################################################
### school type
data2$schooltype <- NA
data2$schooltype[data$schooltype=="Privada"] <- 3
data2$schooltype[data$schooltype=="Publica"] <- 1
data2$schooltype[data$schooltype=="Semi-privada"] <- 2

table1[1,1] <- "School type"
table1[1:3,2] <- c("Public","Semi-Private","Private")

table1[1:3,3:7] <- computetable(data2,62)[,3:7]

#################################################################################
### father education
data2$fathereducation <- NA
data2$fathereducation[data$fathereducation=="Ninguno"] <- 1
data2$fathereducation[data$fathereducation=="Primaria"] <- 2
data2$fathereducation[data$fathereducation=="Secundaria"] <- 3
data2$fathereducation[data$fathereducation=="Tecnico"] <- 4
data2$fathereducation[data$fathereducation=="Universitario"] <- 5
cor(data2$ind,data2$fathereducation, use="complete.obs")

table1[4,1] <- "Father education"
table1[4:8,2] <- c("None","Primary","Secondary","Technical","University")

table1[4:8,3:7] <- computetable(data2,63)[,3:7]

#################################################################################
### mother education
data2$mothereducation <- NA
data2$mothereducation[data$mothereducation=="Ninguno"] <- 1
data2$mothereducation[data$mothereducation=="Primaria"] <- 2
data2$mothereducation[data$mothereducation=="Secundaria"] <- 3
data2$mothereducation[data$mothereducation=="Tecnico"] <- 4
data2$mothereducation[data$mothereducation=="Universitario"] <- 5


table1[9,1] <- "Mother education"
table1[9:13,2] <- c("None","Primary","Secondary","Technical","University")

table1[9:13,3:7] <- computetable(data2,64)[,3:7]

#################################################################################
### shared room
data2$shareroom <- NA
data2$shareroom[data$shareroom=="N"] <- 0
data2$shareroom[data$shareroom=="Y"] <- 1

table1[14,1] <- "Share Room with others"
table1[14:15,2] <- c("No","Yes")
table1[14:15,3:7] <- computetable(data2,65)[,3:7]

table1[16,1] <- "Number of shared adults"
table1[16:20,2] <- c("0","1-2","3-4","5-6",">6")
table1[16:19,3:7] <- computetable(data2,66)[,3:7]

table1[21,1] <- "Number of shared children with age 0-1"
table1[21:25,2] <- c("0","1-2","3-4","5-6",">6")
table1[21:24,3:7] <- computetable(data2,67)[,3:7]

table1[26,1] <- "Number of shared children with age 2-5"
table1[26:30,2] <- c("0","1-2","3-4","5-6",">6")
table1[26:29,3:7] <- computetable(data2,68)[,3:7]

table1[31,1] <- "Number of shared children with age 6-12"
table1[31:35,2] <- c("0","1-2","3-4","5-6",">6")
table1[31:34,3:7] <- computetable(data2,69)[,3:7]

table1[36,1] <- "Number of shared children with age 13-18"
table1[36:40,2] <- c("0","1-2","3-4","5-6",">6")
table1[36:38,3:7] <- computetable(data2,70)[,3:7]

table1[41,1] <- "Number of shared people"
table1[41:45,2] <- c("0","1-2","3-4","5-6",">6")
table1[41:45,3:7] <- computetable(data2,71)[,3:7]

data2$sharebed <- NA
data2$sharebed[data$sharebed=="N"] <- 0
data2$sharebed[data$sharebed=="Y"] <- 1

table1[46,1] <- "Share bed with others"
table1[46:47,2] <- c("No","Yes")
table1[46:47,3:7] <- computetable(data2,72)[,3:7]

table1[48,1] <- "Number of shared adults"
table1[48:52,2] <- c("0","1-2","3-4","5-6",">6")
table1[48:50,3:7] <- computetable(data2,73)[,3:7]

table1[53,1] <- "Number of shared children with age 0-1"
table1[53:57,2] <- c("0","1-2","3-4","5-6",">6")
table1[53:54,3:7] <- computetable(data2,74)[,3:7]

table1[58,1] <- "Number of shared children with age 2-5"
table1[58:62,2] <- c("0","1-2","3-4","5-6",">6")
table1[58:59,3:7] <- computetable(data2,75)[,3:7]

table1[53,1] <- "Number of shared children with age 6-12"
table1[63:67,2] <- c("0","1-2","3-4","5-6",">6")
table1[63:65,3:7] <- computetable(data2,76)[,3:7]

table1[68,1] <- "Number of shared children with age 13-18"
table1[68:72,2] <- c("0","1-2","3-4","5-6",">6")
table1[68:69,3:7] <- computetable(data2,77)[,3:7]

table1[73,1] <- "Total number of shared people"
table1[73:77,2] <- c("0","1-2","3-4","5-6",">6")
table1[73:76,3:7] <- computetable(data2,78)[,3:7]

table1[78,1] <- "Number of household member with age 0-1"
table1[78:82,2] <- c("0","1-2","3-4","5-6",">6")
table1[78:81,3:7] <- computetable(data2,79)[,3:7]

table1[83,1] <- "Number of household member with age 2-5"
table1[83:87,2] <- c("0","1-2","3-4","5-6",">6")
table1[83:87,3:7] <- computetable(data2,80)[,3:7]

table1[88,1] <- "Number of household member with age 6-12"
table1[88:92,2] <- c("0","1-2","3-4","5-6",">6")
table1[88:92,3:7] <- computetable(data2,81)[,3:7]

table1[93,1] <- "Number of household member with age 13-18"
table1[93:97,2] <- c("0","1-2","3-4","5-6",">6")
table1[93:97,3:7] <- computetable(data2,82)[,3:7]

table1[98,1] <- "Number of household member with age > 18"
table1[98:102,2] <- c("0","1-2","3-4","5-6",">6")
table1[98:102,3:7] <- computetable(data2,83)[,3:7]

table1[104,1] <- "Household size"
table1[104:107,2] <- c("1-2","3-4","5-6",">6")
table1[104:107,3:7] <- computetable(data2,84)[,3:7]

cor(data2$ind,data2$shareroom1, use="complete.obs")
cor(data2$ind,data2$shareroom2, use="complete.obs")
cor(data2$ind,data2$shareroom3, use="complete.obs")
cor(data2$ind,data2$shareroom4, use="complete.obs")
cor(data2$ind,data2$shareroom6, use="complete.obs")

cor(data2$ind,data2$sharebed1, use="complete.obs")
cor(data2$ind,data2$sharebed2, use="complete.obs")
cor(data2$ind,data2$sharebed3, use="complete.obs")
cor(data2$ind,data2$sharebed4, use="complete.obs")
cor(data2$ind,data2$sharebed5, use="complete.obs")
cor(data2$ind,data2$sharebed6, use="complete.obs")


cor(data2$ind,data2$nmember1, use="complete.obs")
cor(data2$ind,data2$nmember2, use="complete.obs")
cor(data2$ind,data2$nmember3, use="complete.obs")
cor(data2$ind,data2$nmember4, use="complete.obs")
cor(data2$ind,data2$nmember5, use="complete.obs")
cor(data2$ind,data2$nmember6, use="complete.obs")


data2$faucet <- NA
data2$faucet[data$faucet=="No hay grifos"] <- 0
data2$faucet[data$faucet=="Fuera"] <- 1
data2$faucet[data$faucet=="Dentro"] <- 2
data2$faucet[data$faucet=="Dentro y Fuera"] <- 3
cor(data2$ind,data2$faucet, use="complete.obs")

table1[108,1] <- "Position of faucet"
table1[108:111,2] <- c("No faucet","Outside","Inside","Both")
table1[108:111,3:7] <- computetable(data2,85)[,3:7]

data2$tap <- NA
data2$tap[data$tap=="No hay grifos"] <- 0
data2$tap[data$tap=="Compartido"] <- 1
data2$tap[data$tap=="No compartido"] <- 2
cor(data2$ind,data2$tap, use="complete.obs")

table1[112,1] <- "Faucet shared or not"
table1[112:114,2] <- c("No faucet","Shared","Not shared")
table1[112:114,3:7] <- computetable(data2,86)[,3:7]

data2$floortype <- NA
data2$floortype[data$floortype=="Ceramica"] <- 4
data2$floortype[data$floortype=="Concreto"] <- 3
data2$floortype[data$floortype=="Ladrillos"] <- 2
data2$floortype[data$floortype=="Piso de tierra"] <- 1
cor(data2$ind,data2$floortype, use="complete.obs")

table1[115,1] <- "Floor type"
table1[115:118,2] <- c("Ground","Bricks","Concrete","Ceramic tile")
table1[115:118,3:7] <- computetable(data2,87)[,3:7]

data2$ceilingtype <- NA
data2$ceilingtype[data$ceilingtype=="Zinc"] <- 3
data2$ceilingtype[data$ceilingtype=="Plástico"] <- 2
data2$ceilingtype[data$ceilingtype=="Tejas"] <- 1
cor(data2$ind,data2$ceilingtype, use="complete.obs")

table1[119,1] <- "Ceiling type"
table1[119:121,2] <- c("Roof tiles","Plastic","Zinc")
table1[119:121,3:7] <- computetable(data2,88)[,3:7]

data2$ownhouse <- NA
data2$ownhouse[data$ownhouse=="N"] <- 0
data2$ownhouse[data$ownhouse=="Y"] <- 1
cor(data2$ind,data2$ownhouse, use="complete.obs")

table1[122,1] <- "Home ownership"
table1[122:123,2] <- c("No","Yes")
table1[122:123,3:7] <- computetable(data2,89)[,3:7]

cor(data2$ind,data2$nfan, use="complete.obs")
cor(data2$ind,data2$ntelevision, use="complete.obs")
cor(data2$ind,data2$nrefridgerator, use="complete.obs")

table1[124,1] <- "# of Fans"
table1[124:128,2] <- c("0","1-2","3-4","5-6",">6")
table1[124:128,3:7] <- computetable(data2,90)[,3:7]

table1[129,1] <- "# of television"
table1[129:133,2] <- c("0","1-2","3-4","5-6",">6")
table1[129:133,3:7] <- computetable(data2,91)[,3:7]

table1[134,1] <- "# of refridgerator"
table1[134:138,2] <- c("0","1-2","3-4","5-6",">6")
table1[134:137,3:7] <- computetable(data2,92)[,3:7]

data2$nmoto <- NA
data2$nmoto[data$nmoto=="N"] <- 0
data2$nmoto[data$nmoto=="Y"] <- 1
cor(data2$ind,data2$nmoto, use="complete.obs")

table1[139,1] <- "Own motorcylce"
table1[139:140,2] <- c("No","Yes")
table1[139:140,3:7] <- computetable(data2,93)[,3:7]

data2$ncar <- NA
data2$ncar[data$ncar=="N"] <- 0
data2$ncar[data$ncar=="Y"] <- 1
cor(data2$ind,data2$ncar, use="complete.obs")

table1[141,1] <- "Own cars"
table1[141:142,2] <- c("No","Yes")
table1[141:142,3:7] <- computetable(data2,94)[,3:7]



cor(data2$ind,data2$pollos, use="complete.obs")
cor(data2$ind,data2$patos, use="complete.obs")
cor(data2$ind,data2$perros, use="complete.obs")
cor(data2$ind,data2$gatos, use="complete.obs")
cor(data2$ind,data2$chocoyos, use="complete.obs")
cor(data2$ind,data2$cerdos, use="complete.obs")

data2$ncar <- NA
data2$ncar[data$ncar=="N"] <- 0
data2$ncar[data$ncar=="Y"] <- 1
cor(data2$ind,data2$ncar, use="complete.obs")

data2$polloscasa <- NA
data2$polloscasa[data$polloscasa=="N"] <- 0
data2$polloscasa[data$polloscasa=="Y"] <- 1
cor(data2$ind,data2$polloscasa, use="complete.obs")

data2$patoscasa <- NA
data2$patoscasa[data$patoscasa=="N"] <- 0
data2$patoscasa[data$patoscasa=="Y"] <- 1
cor(data2$ind,data2$patoscasa, use="complete.obs")

data2$perroscasa <- NA
data2$perroscasa[data$perroscasa=="N"] <- 0
data2$perroscasa[data$perroscasa=="Y"] <- 1
cor(data2$ind,data2$perroscasa, use="complete.obs")

data2$gatoscasa <- NA
data2$gatoscasa[data$gatoscasa=="N"] <- 0
data2$gatoscasa[data$gatoscasa=="Y"] <- 1
cor(data2$ind,data2$gatoscasa, use="complete.obs")

data2$chocoyoscasa <- NA
data2$chocoyoscasa[data$chocoyoscasa=="N"] <- 0
data2$chocoyoscasa[data$chocoyoscasa=="Y"] <- 1
cor(data2$ind,data2$chocoyoscasa, use="complete.obs")

data2$cerdoscasa <- NA
data2$cerdoscasa[data$cerdoscasa=="N"] <- 0
data2$cerdoscasa[data$cerdoscasa=="Y"] <- 1
cor(data2$ind,data2$cerdoscasa, use="complete.obs")

data2$cerdoscasa <- NA
data2$cerdoscasa[data$cerdoscasa=="N"] <- 0
data2$cerdoscasa[data$cerdoscasa=="Y"] <- 1
cor(data2$ind,data2$cerdoscasa, use="complete.obs")

data2$ratas <- NA
data2$ratas[data$ratas=="N"] <- 0
data2$ratas[data$ratas=="Y"] <- 1
cor(data2$ind,data2$ratas, use="complete.obs")


table1[143,1] <- "Number of chickens"
table1[143:147,2] <- c("0","1-2","3-4","5-6",">6")
table1[143:147,3:7] <- computetable(data2,95)[,3:7]

table1[148,1] <- "Chickens in houses"
table1[148:149,2] <- c("No","Yes")
table1[148:149,3:7] <- computetable(data2,96)[,3:7]

table1[150,1] <- "Number of ducks"
table1[150:154,2] <- c("0","1-2","3-4","5-6",">6")
table1[150:154,3:7] <- computetable(data2,97)[,3:7]

table1[155,1] <- "Ducks in houses"
table1[155:156,2] <- c("No","Yes")
table1[155:156,3:7] <- computetable(data2,98)[,3:7]

table1[157,1] <- "Number of dogs"
table1[157:161,2] <- c("0","1-2","3-4","5-6",">6")
table1[157:161,3:7] <- computetable(data2,99)[,3:7]

table1[162,1] <- "Dogs in houses"
table1[162:163,2] <- c("No","Yes")
table1[162:163,3:7] <- computetable(data2,100)[,3:7]

table1[164,1] <- "Number of cats"
table1[164:168,2] <- c("0","1-2","3-4","5-6",">6")
table1[164:167,3:7] <- computetable(data2,101)[,3:7]

table1[169,1] <- "Cats in houses"
table1[169:170,2] <- c("No","Yes")
table1[169:170,3:7] <- computetable(data2,102)[,3:7]

table1[171,1] <- "Number of birds"
table1[171:175,2] <- c("0","1-2","3-4","5-6",">6")
table1[171:175,3:7] <- computetable(data2,103)[,3:7]

table1[176,1] <- "Birds in houses"
table1[176:177,2] <- c("No","Yes")
table1[176:177,3:7] <- computetable(data2,104)[,3:7]

table1[178,1] <- "Number of pigs"
table1[178:182,2] <- c("0","1-2","3-4","5-6",">6")
table1[178:181,3:7] <- computetable(data2,105)[,3:7]

table1[183,1] <- "Pigs in houses"
table1[183:184,2] <- c("No","Yes")
table1[183:184,3:7] <- computetable(data2,106)[,3:7]

table1[185,1] <- "Rats in houses"
table1[185:186,2] <- c("No","Yes")
table1[185:186,3:7] <- computetable(data2,107)[,3:7]

table2 <- table1
table2[,5:7] <- round(table2[,5:7],3)
names(table2) <- c("Variable","Levels","Number of infection","Number of person-year","Indcidence","Correlation","p-value")
table2[is.na(table2)] <- " "

table3 <- table2[c(1:13,104:137,139:142,148:149,155:156,162:163,169,170,176:177,183:186),]

table3[,5] <- round(as.numeric(table3[,5]),2)

write.table(table3,"/Users/timtsang/Dropbox2/Dropbox/Nicaragua/version/natcomm/tableS6.csv",row.names = F, col.names = F,sep = ",")

write.table(table3,"/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/TableS5.csv",row.names = F, col.names = F,sep = ",")