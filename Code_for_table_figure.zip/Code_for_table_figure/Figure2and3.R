library(ggplot2)
library(gridExtra)

a1 <- read.csv("Figure2.csv")
a2 <- read.csv("Figure3.csv")

df.inf <- data.frame(
  group = c("Age (Ref=2-8 yr)", "", "# of prior infections (Ref=0)", "", "", "Years since primary infection (Ref=1)", "", "", 
            "Years since most recent non-primary infection (Ref=1)", "", "", "House Ownership (Ref=No)", "", "# of fans (Ref=0)", rep("",4)),
  subgroup = c("", "Children > 8 yr", "", "1", ">1", "", "2", ">2", "", "2", ">2", "", "Yes", "", "1-2", "3-4", "5-6", ">6"),
  idx = 18:1,
  odds.ratio = c(NA, 1.53, NA, 0.45, 1.79, NA, 1.13, 1.52, NA, 0.80, 0.75, NA, 0.80, NA, 0.67, 0.66, 0.54, 0.55),
  ci.low =     c(NA, 1.37, NA, 0.36, 1.28, NA, 0.77, 1.15, NA, 0.47, 0.50, NA, 0.71, NA, 0.60, 0.58, 0.45, 0.40),
  ci.high =    c(NA, 1.71, NA, 0.58, 2.63, NA, 1.66, 1.93, NA, 1.30, 1.12, NA, 0.89, NA, 0.77, 0.77, 0.65, 0.75)
)

df.inf[c(2,4,5,7,10,8,11,13,15:18),4:6] <- a1[1:12,1:3]

p <- ggplot(df.inf, aes(odds.ratio, idx)) 
p <- p + geom_point() + scale_x_continuous(breaks = c(0.25, 0.5, 1, 2), labels = c(0.25, 0.5, 1, 2), limits=c(0.25, 2.8), trans = "log2") + labs(x = "Odds Ratio", y = NULL)
p <- p + theme(axis.ticks.y = element_blank(), axis.text.y = element_blank(), axis.title.y = element_blank(), axis.line.x=element_line(colour = "black"),
               panel.grid.minor=element_blank(), panel.grid.major=element_blank(), panel.background=element_blank(), panel.border=element_blank(),
               axis.text=element_text(size=12), axis.title=element_text(size=14,face="bold"))
p <- p + geom_errorbarh(aes(xmin=ci.low, xmax=ci.high, height = .2), colour='blue') + geom_vline(xintercept = 1, linetype=2, colour='red')
p <- p + geom_text(aes(label = subgroup, x = rep(0.3,nrow(df.inf))), hjust = 0) + geom_text(aes(label = group, x = rep(0.25,nrow(df.inf))), hjust = 0)
pdf('/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/figure2.pdf', width=8, height=8) 
p
dev.off()




df.sym <- data.frame(
  group = c("Age (Ref=2-8 yr)", "","2-8 yr old, # of prior infections (Ref=0)", "", "",">8 yr old, # of prior infections (Ref=0)", "", "" 
            , "2-8 yr old, Years since most recent infection (Ref=1)", "", "", 
            ">8 yr old, Years since most recent infection (Ref=1)", "", ""                          ),
  subgroup = c("", "Children > 8 yr","", "1",">1","","1",">1","", "2", ">2", "", "2", ">2"),
  idx = 14:1,
  odds.ratio = rep(NA,14),
  ci.low =     rep(NA,14),
  ci.high =    rep(NA,14)
)

df.sym[c(2,4,5,7,8,10,11,13,14),4:6] <- a2[5:13,1:3]

df.sym.prob <- data.frame(
  subgroup = paste("DENV-", 1:4, sep=''),
  idx = c(0.4, 0.3, 0.2, 0.1),
  prob =    c(0.11, 0.15, 0.32, 0.02),
  ci.low =  c(0.08, 0.12, 0.27, 0.0001),
  ci.high = c(0.13, 0.18, 0.38, 0.06)
)

df.sym.prob[,3:5] <- a2[1:4,1:3]

p1 <- ggplot(df.sym, aes(odds.ratio, idx)) 
p1 <- p1 + geom_point() + scale_x_continuous(breaks = c(0.02, 0.1, 0.25, 0.5, 1, 2, 4), labels = c(0.02, 0.1, 0.25, 0.5, 1, 2, 4), limits=c(0.004, 4), trans = "log2") + labs(x = "(B) Odds Ratio", y = NULL)
p1 <- p1 + theme(axis.ticks.y = element_blank(), axis.text.y = element_blank(), axis.title.y = element_blank(), axis.line.x=element_line(colour = "black"),
               panel.grid.minor=element_blank(), panel.grid.major=element_blank(), panel.background=element_blank(), panel.border=element_blank(),
               axis.text=element_text(size=14), axis.title=element_text(size=14,face="bold"))
p1 <- p1 + geom_errorbarh(aes(xmin=ci.low, xmax=ci.high, height = .2), colour='blue') + geom_vline(xintercept = 1, linetype=2, colour='red')
p1 <- p1 + geom_text(aes(label = subgroup, x = rep(0.015,nrow(df.sym))), hjust = 0, size=5) + geom_text(aes(label = group, x = rep(0.005,nrow(df.sym))), hjust = 0, size=5)

p2 <- ggplot(df.sym.prob, aes(prob, idx)) 
p2 <- p2 + geom_point() + scale_x_continuous(breaks = seq(0, 0.30, by=0.05), labels = seq(0, 0.30, by=0.05), limits=c(-0.1,0.30)) + labs(x = "(A) Probability of Disease Given Infection", y = NULL)
p2 <- p2 + theme(axis.ticks.y = element_blank(), axis.text.y = element_blank(), axis.title.y = element_blank(), axis.line.x=element_line(colour = "black"),
               panel.grid.minor=element_blank(), panel.grid.major=element_blank(), panel.background=element_blank(), panel.border=element_blank(),
               axis.text=element_text(size=14), axis.title=element_text(size=14,face="bold"))
p2 <- p2 + geom_errorbarh(aes(xmin=ci.low, xmax=ci.high, height = .1), colour='blue')
p2 <- p2 + geom_text(aes(label = subgroup, x = rep(-0.05,nrow(df.sym.prob))), size=5)
p2 <- p2 + geom_vline(xintercept = seq(0, 0.30, by=0.05), linetype=2, colour='grey')

pdf('/Users/timtsang/Dropbox2/Dropbox/Nicaragua/upload/figure3.pdf', width=12, height=8) 
grid.arrange(p2, p1, nrow=1, ncol=2, widths=c(6,6), heights=8)
dev.off()

