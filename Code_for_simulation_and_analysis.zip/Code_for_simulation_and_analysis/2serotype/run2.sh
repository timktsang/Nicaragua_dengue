#!/bin/bash
#SBATCH --job-name=1st
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=4gb
#SBATCH --time=70:00:00
#SBATCH --account=epi
#SBATCH --qos=epi-b

pwd; hostname; date

cat /proc/cpuinfo

module load R

Rscript dengue_main_2serotype.r 

date
