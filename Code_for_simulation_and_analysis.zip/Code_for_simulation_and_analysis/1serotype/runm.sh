#!/bin/bash
#SBATCH --job-name=1st
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --mem=4gb
#SBATCH --time=70:00:00
#SBATCH --account=epi
#SBATCH --qos=epi

pwd; hostname; date

cat /proc/cpuinfo

module load R

Rscript dengue_main_1serotype.r 

date
