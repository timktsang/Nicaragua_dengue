### program for de
rm(list = ls())

library(Rcpp)
library(RcppParallel)
print(defaultNumThreads())

#setThreadOptions(numThreads = 10)

########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
  y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
  y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
  for (i in 1:ncol(mcmc)){
  plot(mcmc[,i],type="l")
  }
  }
  return(y)
}

## create function to count the adjfactor

compute_adjfactor <- function(data1){
xx <- matrix(NA,nrow(data1),15)
for (i in 1:nrow(xx)){
xx[i, (9+data1[i,5]-data1[i,3]+1):(9+data1[i,6])] <- (9+data1[i,5]-data1[i,3]+1):(9+data1[i,6])
}
return(1000/table(xx))
}

########

getwd()

data1 <- as.matrix(read.csv("data_template.csv",header=T))
data1[data1[,c("yinf_1")]==999,c("yinf_1")] <- 0
data1[data1[,c("yinf_2")]==999,c("yinf_2")] <- 0
data1[data1[,c("yinf_3")]==999,c("yinf_3")] <- 0
data1[data1[,c("yinf_4")]==999,c("yinf_4")] <- 0

data2 <- as.matrix(read.table("reported_n.txt",header=F))

data3 <- data1[,54:59]
## para: effect on infection
## 1-15：probability of infection for serotype 1
## 16-30：probability of infection for serotype 1
## 31-45：probability of infection for serotype 1
## 46-60：probability of infection for serotype 1

## 61: number of prior infection ==1
## 62: number of prior infection >=2
## 63: year since last infection ==2
## 64: year since last infection >=3
## 65: last infection age >=6
## 66: effect of symptom or not in last infection

## para2: parameter for effect on symptom
## 67-70：parameter for 4 type
## 71: number of prior infection ==1
## 72: number of prior infection >=2
## 73: year since last infection ==2
## 74: year since last infection >=3
## 75: last infection age >=6
## 76: effect of symptom or not in last infection
## 77: q in the negative bionomial distribution

sourceCpp("dengue_1serotype.cpp")

int_para <-  c(rep(0,4),c(0.02,0.05,0.02,0.02,0.02,0.02,0.06,0.02,0.02,0.02,0.03),
               rep(0,4),c(0.02,0.02,0.02,0.04,0.02,0.08,0.07,0.05,0.07,0.02,0.02),
               rep(0,4),c(0.04,0.02,0.03,0.06,0.06,0.02,0.03,0.07,0.04,0.02,0.11),
               rep(0,4),c(0.02,0.02,0.04,0.02,0.02,0.07,0.02,0.06,0.02,0.02,0.07)
               ,c(1,1.5,0.5,0.4,-0.5),0
               ,c(0.3,0.2,0.4,0.1),c(-0.5,-1,-0.1,-0.2),0,0,c(0.1))
print(int_para)

## reduce data for simulation
data1 <- data1[data1[,5]==1&data1[,6]==6,]

data1[,3] <- sample(1:6,nrow(data1),T)


adjfactor <- c(rep(0,4),as.vector(compute_adjfactor(data1)))

t <- sim_data(data1,int_para,c(0.05,0.6),adjfactor)

## try to seperate the data into a class with same infection outcome
## try later, because it may not be useful when add elisa

sigma <- c(rep(0.01,2),rep(0.005,2),rep(0.01,2),rep(0.003,2),
           rep(0.005,4),rep(0.003,3),
           rep(0.015,2),0.005,0.015,rep(0.005,3),0.01,0.003,
           rep(0.01,4),0.004,0.005,
           rep(0.016,3),rep(0.005,4),rep(0.003,2),rep(0.005,3),
           0.002,rep(0.015,2),
           rep(0.01,2),rep(0.005,5),rep(0.001,2),rep(0.004,3),
           rep(0.002,3),
           rep(0.3,3),0.13,rep(0.35,2),
           0.09,0.05,0.08,0.07,
           2.45,0.5,0.9,0.4,1.2,1.6
           ,rep(0.02,1))


move <- rep(1,77)
move[c(66,75,76)] <- 0
move[c(1:4,1:4+15,1:4+30,1:4+45)] <- 0

## mcmc, first use count_combination to create 
## 1: the total possible combination
## 2: the consistent matrix that indicate for each case, 
## which rows of combination will fit this observation, each col is for each person
## then use mcmc to run

combination <- count_combination(t[[3]])

para <- c(runif(60,0.02,0.1),runif(5,-1,1),0,runif(4,0.02,0.5),runif(4,-1,1),0,0,rep(0.1,1))



aaaaa1 <- Sys.time()
tt <- mcmc(t[[3]],t[[2]],t[[3]][,54:59],combination[[1]],combination[[2]],adjfactor,11000,para,4,move,sigma)
aaaaa2 <- Sys.time()
print(aaaaa2-aaaaa1)


inc <- 1001:11000
z1 <- para_summary((tt[[1]][inc,]),4,4,1)
print(z1)

write.csv(z1,paste("summary_",runif(1,0,1),".csv"))
