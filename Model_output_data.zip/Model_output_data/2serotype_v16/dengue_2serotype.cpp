#include <RcppArmadilloExtensions/sample.h>
#include <Rcpp.h>
#include <RcppParallel.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::depends(RcppParallel)]]
using namespace Rcpp ;
using namespace RcppParallel;


//########################################################################################################################################
// function to generate normal random variable
// [[Rcpp::export]]
double rnorm(double a, double b) { // a: mean, b: s.d.
	double c=a+b*sum(rnorm(1));
    return c;
}

//########################################################################################################################################
// function to compute the nb distribution
// [[Rcpp::export]]
double dnb(int n, int m, double c) { 
	
double d=R::dpois(n,(m+1)/c,1);
return d;
}

//########################################################################################################################################
// function to for inverse of logit
// [[Rcpp::export]]
double logit(double a) { 
    return log(a/(1-a));
}

//########################################################################################################################################
// function to for inverse of logit
// [[Rcpp::export]]
double invlogit(double a) { 
    return exp(a)/(1+exp(a));
}


//########################################################################################################################################
// function to generate binomial random number
// [[Rcpp::export]]
int gen_binom(double p){
double cut=(double)rand()/(RAND_MAX);
int out=0;
if (cut<p){
out=1;
}
return out;
}

//########################################################################################################################################
// function to general multiviariable normal given sigma
// [[Rcpp::export]]
NumericVector rmnorm(arma::mat sigma) {
int ncols=sigma.n_cols;
arma::rowvec c=arma::randn(1,ncols);
arma::rowvec a=c*arma::chol(sigma);   
NumericVector b=NumericVector(a.begin(),a.end());   
return b;
}

//########################################################################################################################################
//function to compute the prior likelihood 
// [[Rcpp::export]]
double prior_loglik(NumericVector para){
// check if the para are within their possible range
double out=1;
int b1;
for (b1=59;b1>=0;--b1){
out*=sum(dunif(NumericVector::create(para(b1)),0.0001,0.9999));
}

for (b1=65;b1>=60;--b1){
out*=sum(dunif(NumericVector::create(para(b1)),-10.0,10.0));
}

for (b1=69;b1>=66;--b1){
out*=sum(dunif(NumericVector::create(para(b1)),0.0001,0.9999));
}

for (b1=75;b1>=70;--b1){
out*=sum(dunif(NumericVector::create(para(b1)),-10.0,10.0));
}

out*=sum(dunif(NumericVector::create(para(76)),0.0001,0.9999));


// if the prior is outside the parameter space
if (out==0){
out=-9999999;
}
else{
out=log(out);	
}
return out;
}


//########################################################################################################################################
//########################################################################################################################################
// the main body of the parallel for Digraphlikelihood
struct LogLik:public Worker{
// source vector
RVector<double> out;
RMatrix<int> data11;
RVector<double> para;
int inf_part;
int sym_part;
RMatrix<double> record;
// destination vector
// initialize with source and destination
LogLik(NumericVector out,
IntegerMatrix data11,
NumericVector para,
int inf_part,
int sym_part,
NumericMatrix record) 
:out(out),data11(data11),para(para),inf_part(inf_part),sym_part(sym_part),record(record){}
void operator()(std::size_t begin, std::size_t end) {

// section to write the parallel version
// functor (pass input and output matrixes)
for (unsigned int b1=begin;b1<end;++b1){
int b2;
int b3;
int b4;
double p[4];
double covariate_eff_inf;
double covariate_eff_sym;
double sym_prob;
double inf_prob;
int infectstatus;		
int counter;
int numberofinfection=0;
int yearsincelastinfection=1;
int symptomlastinfection=0;
int agelastinfection=0;
int symptomallinfection=0;

for (b2=0;b2<=data11(b1,10)-1+data11(b1,12)-data11(b1,11);++b2){
//record(b1,b2)=data11(b1,1)+b2;
int infectedserotype=-1;
for (b4=3;b4>=0;--b4){
// serach the infected serotype
if (data11(b1,b4+2)==b2+1){
infectedserotype=b4;
}
}
// for the infection part
if (inf_part==1){
counter=0;
// count is it already infected all serotype
for (b4=3;b4>=0;--b4){
if ((data11(b1,b4+2)<b2+1)&&(data11(b1,b4+2)>0)){
++counter;
}	
}
if (counter==4){
goto stop1;
}
// compute covariate effect of infection
covariate_eff_inf=para[60]*(numberofinfection==1)+para[61]*(numberofinfection>=2); 
covariate_eff_inf+=(numberofinfection>0)*(para[62]*(yearsincelastinfection==1)+para[63]*(yearsincelastinfection==2));
//covariate_eff_inf+=(numberofinfection>0)*para[64]*(agelastinfection>=6);
covariate_eff_inf+=(numberofinfection>0)*para[64]*(symptomlastinfection==1);
// compute the probability for 4 serotype
p[0]=logit(para[data11(b1,1)+b2])+covariate_eff_inf;
p[1]=logit(para[15+data11(b1,1)+b2])+covariate_eff_inf;
p[2]=logit(para[30+data11(b1,1)+b2])+covariate_eff_inf;
p[3]=logit(para[45+data11(b1,1)+b2])+covariate_eff_inf;
p[0]=invlogit(p[0]);
p[1]=invlogit(p[1]);
p[2]=invlogit(p[2]);
p[3]=invlogit(p[3]);


for (b4=3;b4>=0;--b4){
// remove the already infected serotype
if ((data11(b1,b4+2)<b2+1)&&(data11(b1,b4+2)>0)){
p[b4]=0;
}
if (p[b4]==1){
p[b4]=0.9999999;	
}
//record(b1,b2*5+1+b4)=p[b4];
}

// if escape
if (infectedserotype==-1){
out[b1]+=log(1-p[0])+log(1-p[1])+log(1-p[2])+log(1-p[3]);
}
// otherwise
else{
out[b1]+=log(1-(1-p[0])*(1-p[1])*(1-p[2])*(1-p[3]));
for (b4=3;b4>=0;--b4){
if (b4!=infectedserotype){	
out[b1]+=log(1-log(1-p[b4])/log((1-p[0])*(1-p[1])*(1-p[2])*(1-p[3])));	
}
}
out[b1]+=log(log(1-p[infectedserotype])/log((1-p[0])*(1-p[1])*(1-p[2])*(1-p[3])));
}
}
//record(b1,b2*5+5)=log(1-(1-p[0])*(1-p[1])*(1-p[2])*(1-p[3]));
// for the sym part
if (sym_part==1){
// confirm it is infection
if (infectedserotype!=-1){
// compute the symptom probability
covariate_eff_sym=(numberofinfection>0)*(para[70]*(symptomallinfection==0)+para[71]*(symptomallinfection==1)); 
covariate_eff_sym+=(numberofinfection>0)*(para[72]*(yearsincelastinfection==1)+para[73]*(yearsincelastinfection==2));
//covariate_eff_sym+=para[74]*(agelastinfection>=6);
//covariate_eff_sym+=para[75]*(symptomlastinfection==1);	
// compute the symptom probability
sym_prob=logit(para[66+infectedserotype])+covariate_eff_sym;
sym_prob=invlogit(sym_prob);
if (data11(b1,infectedserotype+6)==1){
out[b1]+=log(sym_prob);
}
else{
out[b1]+=log(1-sym_prob);
}
}
}

// set the inforation that need to be used
// infected
if (infectedserotype!=-1){
++numberofinfection;
agelastinfection=b2+1;
// reset
yearsincelastinfection=1;
symptomlastinfection=data11(b1,infectedserotype+6);
if (data11(b1,infectedserotype+6)==1){
symptomallinfection=1;	
}

}
// non-infected
else{
++yearsincelastinfection;
}
}
stop1: ;


}
}
};

//########################################################################################################################################
//function to compute likelihood for infection and symptom
// [[Rcpp::export]]
NumericVector loglik(IntegerMatrix data11,
NumericVector para,
int inf_part,
int sym_part){
// check if the para are within their possible range
NumericVector out(data11.nrow());
NumericMatrix record(2,2);
// call parallel program
LogLik loglik(out,data11,para,inf_part,sym_part,record);
// call parallelFor to do the work
parallelFor(0,data11.nrow(),loglik);

return out;
}


//########################################################################################################################################
// function to group the observation with all same outcome into a class
// [[Rcpp::export]]
IntegerVector data_class(NumericMatrix data1){

IntegerVector dataclass(data1.nrow());

int b1;
int b2;
int b3;
int counterclass=1;

for (b1=data1.nrow()-1;b1>=0;--b1){
if (dataclass(b1)==0){
dataclass(b1)=counterclass;
for (b2=b1-1;b2>=0;--b2){
if (data1(b2,2)!=data1(b1,2)){
goto stop3;
}
for (b3=44;b3>=4;--b3){
if (data1(b2,b3)!=data1(b1,b3)){
goto stop3;
}
}
for (b3=58;b3>=53;--b3){
if (data1(b2,b3)!=data1(b1,b3)){
goto stop3;
}
}
dataclass(b2)=counterclass;
stop3: ;
}
++counterclass;
}	
}	

return dataclass;
}

//########################################################################################################################################
//########################################################################################################################################
// the main body of the parallel for doing simulation
struct SimData:public Worker{
// source vector
RMatrix<double> data1;
RMatrix<int> data11;
RMatrix<double> datareal;
RVector<double> para;
RVector<double> missing_prob;
RMatrix<double> record;
// destination vector
// initialize with source and destination
SimData(NumericMatrix data1,
IntegerMatrix data11,
NumericMatrix datareal,
NumericVector para,
NumericVector missing_prob,
NumericMatrix record) 
:data1(data1),data11(data11),datareal(datareal),para(para),missing_prob(missing_prob),record(record){}
void operator()(std::size_t begin, std::size_t end) {

// section to write the parallel version
// functor (pass input and output matrixes)
for (unsigned int b1=begin;b1<end;++b1){
double inf_serotype;	
int b2;
int b3;
int b4;
double p[4];
double covariate_eff_inf;
double covariate_eff_sym;
double inf_prob;
double sym_prob;
int infectstatus;	
int numberofinfection=0;
int yearsincelastinfection=1;
int symptomlastinfection=0;
int agelastinfection=0;
int symptomallinfection=0;
// set the id
data11(b1,0)=data1(b1,0);
// set the column that get the information of serviellance
data11(b1,1)=9+data1(b1,5)-(data1(b1,2)+data1(b1,5)-data1(b1,4));
data11(b1,10)=data1(b1,2);
data11(b1,11)=data1(b1,4);
data11(b1,12)=data1(b1,5);

// data1(b1,2)-1+data1(b1,5)-data1(b1,4) the largest age that the people provide information
// for each year compute the likelihood and do simulate


for (b2=0;b2<=data1(b1,2)-1+data1(b1,5)-data1(b1,4);++b2){
// if already infected or serotype, no need to continue	
if ((data11(b1,2)==0)||(data11(b1,3)==0)||(data11(b1,4)==0)||(data11(b1,5)==0)){
//record(b1,b2)=data11(b1,1)+b2;		
// compute covariate effect of infection
covariate_eff_inf=para[60]*(numberofinfection==1)+para[61]*(numberofinfection>=2); 
covariate_eff_inf+=(numberofinfection>0)*(para[62]*(yearsincelastinfection==1)+para[63]*(yearsincelastinfection==2));
//covariate_eff_inf+=(numberofinfection>0)*para[64]*(agelastinfection>=6);
covariate_eff_inf+=(numberofinfection>0)*para[64]*(symptomlastinfection==1);
// compute the probability for 4 serotype
p[0]=logit(para[data11(b1,1)+b2])+covariate_eff_inf;
p[1]=logit(para[15+data11(b1,1)+b2])+covariate_eff_inf;
p[2]=logit(para[30+data11(b1,1)+b2])+covariate_eff_inf;
p[3]=logit(para[45+data11(b1,1)+b2])+covariate_eff_inf;
p[0]=invlogit(p[0]);
p[1]=invlogit(p[1]);
p[2]=invlogit(p[2]);
p[3]=invlogit(p[3]);
// take out the serotype in non-risk set
for (b4=3;b4>=0;--b4){
if (data11(b1,b4+2)!=0){
p[b4]=0;
}	
record(b1,b4+1)=p[b4];
}

inf_prob=1-(1-p[0])*(1-p[1])*(1-p[2])*(1-p[3]);
infectstatus=gen_binom(inf_prob);
// temp to put the inf_prob
//record(b1,b2*5+5)=agelastinfection;
// for infection
if (infectstatus==1){
// compute the symptom probability
covariate_eff_sym=(numberofinfection>0)*(para[70]*(symptomallinfection==0)+para[71]*(symptomallinfection==1)); 
covariate_eff_sym+=(numberofinfection>0)*(para[72]*(yearsincelastinfection==1)+para[73]*(yearsincelastinfection==2));
//covariate_eff_sym+=para[74]*(agelastinfection>=6);
//covariate_eff_sym+=para[75]*(symptomlastinfection==1);	
// add the number of prior infection	
++numberofinfection;
// reset the year since last infection equal to one
yearsincelastinfection=1;
// change the age of the last infection
agelastinfection=b2+1;
// determine the subtype
double inf_serotype=((double)rand()/(RAND_MAX));
inf_serotype*=(log(1-inf_prob));
if (b2==0){
record(b1,5)=log(1-inf_prob);
record(b1,6)=log(1-p[0]);
record(b1,7)=log(1-p[1]);
record(b1,8)=log(1-p[2]);
record(b1,9)=log(1-p[3]);
record(b1,11)=inf_serotype;
}
for (b3=3;b3>=0;--b3){
inf_serotype-=log(1-p[b3]);
// if take this serotype
if (inf_serotype>0){
if (b2==0){
record(b1,10)=b3+1;
}
// set the indicator equal to one
data11(b1,b3+2)=b2+1;
// compute the symptom probability
sym_prob=logit(para[66+b3])+covariate_eff_sym;
sym_prob=invlogit(sym_prob);
// update the information of last infection
symptomlastinfection=gen_binom(sym_prob);
data11(b1,b3+6)=symptomlastinfection;
if (symptomlastinfection==1){
symptomallinfection=1;	
}

// break out from the loop to avoid setting more than 1 infection
break;
}
}
}
// for non-infection
else{
++yearsincelastinfection;	
}
}
}

// reconstruct the data to the real data format with missing (all infections before entering study were unknown)
// first reset all -1
for (b2=58;b2>=6;--b2){
datareal(b1,b2)=-1;	
}

for (b2=3;b2>=0;--b2){
// if infection occur prebaseline
if ((data11(b1,b2+2)!=0)&&(data11(b1,b2+2)<data11(b1,10))){
datareal(b1,10+b2)=2;
}
if ((data11(b1,b2+2)!=0)&&(data11(b1,b2+2)>=data11(b1,10))){
// infection occur during the study
datareal(b1,15+(data11(b1,b2+2)-data11(b1,10)+data11(b1,11)-1)*5+b2)=1;
datareal(b1,6+b2)=data11(b1,b2+2)-data11(b1,10)+data11(b1,11);
// in this situation can provide symptom information
datareal(b1,53+(data11(b1,b2+2)-data11(b1,10)+data11(b1,11)-1))=data11(b1,b2+6);
}
}


// setting others to 0
for (b2=5;b2>=0;--b2){
if ((b2+1>=data11(b1,11))&&(b2+1<=data11(b1,12))){
for (b3=3;b3>=0;--b3){
if (datareal(b1,15+b2*5+b3)==-1){
datareal(b1,15+b2*5+b3)=0;	
}	
}
if (datareal(b1,53+b2)==-1){
datareal(b1,53+b2)=0;
}
if (datareal(b1,15+b2*5)+datareal(b1,15+b2*5+1)+datareal(b1,15+b2*5+2)+datareal(b1,15+b2*5+3)==0){
datareal(b1,15+b2*5+4)=1;
}
else{
datareal(b1,15+b2*5+4)=0;	
}
}
}

for (b2=4;b2>=0;--b2){
if (datareal(b1,10+b2)==-1){
datareal(b1,10+b2)=0;	
}	
}
for (b2=3;b2>=0;--b2){
if (datareal(b1,10+b2)==0){
if (datareal(b1,6+b2)==-1){
datareal(b1,6+b2)=0;
}
}
}


// construct missing
// prob1: missing completely
// prob2: missing the subtype when infection do occur

// missing prebaseline
if (gen_binom(missing_prob[0])){
for (b2=3;b2>=0;--b2){
datareal(b1,10+b2)=1;	
// change the 7-10 indicator
if (datareal(b1,6+b2)==0){
datareal(b1,6+b2)=-1;	
}
}
}	


// missing infection during study year
for (b2=5;b2>=0;--b2){
if ((b2+1<=datareal(b1,5))&&(b2+1>=datareal(b1,4))){
// count the infection number for that year first
int infectionno=0;
for (b3=3;b3>=0;--b3){
if (datareal(b1,15+b2*5+b3)==1){
infectionno=1;
}
}
// then do the missing according to the situation
if (infectionno==1){
if (gen_binom(missing_prob[1])){
for (b3=3;b3>=0;--b3){
datareal(b1,15+b2*5+b3)=1;
// change the 7-10 indicator
if ((datareal(b1,6+b3)==0)||(datareal(b1,6+b3)==b2+1)){
datareal(b1,6+b3)=-1;	
}
}
}
else if(gen_binom(missing_prob[0])){
for (b3=4;b3>=0;--b3){
datareal(b1,15+b2*5+b3)=1;
// change the 7-10 indicator
if (b3<=3){
if (datareal(b1,6+b3)==0||(datareal(b1,6+b3)==b2+1)){
datareal(b1,6+b3)=-1;	
}
}
}
}
}
// non-infection
else{
if (gen_binom(missing_prob[0])){
for (b3=4;b3>=0;--b3){
datareal(b1,15+b2*5+b3)=1;
// change the 7-10 indicator
if (b3<=3){
if (datareal(b1,6+b3)==0){
datareal(b1,6+b3)=-1;	
}
}
}
}
}
}
}

// need to set that if there is one confirm infection for a serotype, then can not be infected at other year
for (b2=3;b2>=0;--b2){
// if infected before study
if (datareal(b1,10+b2)==2){
for (b3=5;b3>=0;--b3){
if (datareal(b1,15+b3*5+b2)!=-1){	
datareal(b1,15+b3*5+b2)=0;
}
}
}
// if infected during the study
if (datareal(b1,6+b2)>0){
for (b3=5;b3>=0;--b3){
if (b3+1!=datareal(b1,6+b2)){
if (datareal(b1,15+b3*5+b2)!=-1){
datareal(b1,15+b3*5+b2)=0;
}
}
}
}
}

// set the 7-10 indicator
// if 0 mean confirmed non-infection for a sero type, otherwise they are -1



}
}
};

//########################################################################################################################################
//function to do simulation
// [[Rcpp::export]]
List sim_data(NumericMatrix data1,
NumericVector para,
NumericVector missing_prob,
NumericVector adjfactor){ // to count the number of variable
// clone the data first
// 1. id
// 2. the beginnin of the seruviallance row (0-15)
// 3. serotype 1 infection age
// 4. serotype 2 infection age
// 5. serotype 3 infection age
// 6. serotype 4 infection age
// 7. symptom or not
// 8. symptom or not
// 9. symptom or not
// 10. symptom or not
// 11. age at year 1
// 12. first year
// 13. last year
IntegerMatrix data11(data1.nrow(),13);
IntegerMatrix data21(4,15);
NumericMatrix record(data1.nrow(),200);
NumericMatrix datareal(clone(data1));
SimData simdata1(data1,data11,datareal,para,missing_prob,record);
// call parallelFor to do the work
parallelFor(0,data1.nrow(),simdata1);

// need to compute the survillence based on negative bioomial distribution
// first need to count the number of infection for each year
int b1;
int b2;
for (b1=data11.nrow()-1;b1>=0;--b1){
for (b2=3;b2>=0;--b2){
if (data11(b1,b2+2)!=0){
++data21(b2,data11(b1,b2+2)+data11(b1,1)-1);
}
}
}

for (b1=14;b1>=0;--b1){
for (b2=3;b2>=0;--b2){
data21(b2,b1)=R::rpois((data21(b2,b1)*adjfactor(b1)+1)/para[76]);	
}	
}


return List::create(_[""]=data11,
_[""]=data21,	
_[""]=datareal,
_[""]=record);
} 


//########################################################################################################################################
//########################################################################################################################################
// the main body of the parallel for check consistent
struct CheckConsistent:public Worker{
// source vector
RMatrix<double> data1;
RMatrix<int> combination;
RMatrix<int> consistent;
// destination vector
// initialize with source and destination
CheckConsistent(NumericMatrix data1,
IntegerMatrix combination,
IntegerMatrix consistent) 
:data1(data1),combination(combination),consistent(consistent){}
void operator()(std::size_t begin, std::size_t end) {

// section to write the parallel version
// functor (pass input and output matrixes)
for (unsigned int b1=begin;b1<end;++b1){
int b2;
int b3;
int b4;
int counter=0;
if (data1(b1,6)==0&&data1(b1,7)==0&data1(b1,8)==0&data1(b1,9)==0){
consistent(counter,b1)=1;
}
else{
for (b2=combination.nrow()-1;b2>=0;--b2){
// first drop infection year exceed the person total follow year
for (b3=3;b3>=0;--b3){
if (combination(b2,b3)>data1(b1,2)+data1(b1,5)-data1(b1,4)){
//consistent(b2,b1)=0;
goto stop2;
}
}
// try to test if one condition wrong, then set 0 and break	
// test the col 7 - 10 in dataset
for (b3=3;b3>=0;--b3){	
if ((data1(b1,b3+6)>0)&&(data1(b1,b3+6)+data1(b1,2)-data1(b1,4)!=combination(b2,b3))){
//consistent(b2,b1)=0;
goto stop2;
}
if ((data1(b1,b3+6)==0)&&(combination(b2,b3)!=0)){
//consistent(b2,b1)=0;
goto stop2;
}
}


// test the col 11-15 in dataset, it is baseline data
for (b3=3;b3>=0;--b3){
// if not infected at baseline
if (data1(b1,b3+10)==0){
// reject the data with infection at baseline	
if ((combination(b2,b3)<=data1(b1,2)-1)&&(combination(b2,b3)>0)){
//consistent(b2,b1)=0;
goto stop2;
}
}
// if confirmed infected at baseline	
if (data1(b1,b3+10)==2){
// reject if it is not infected at baseline	
if ((combination(b2,b3)>data1(b1,2)-1)||(combination(b2,b3)==0)){
//consistent(b2,b1)=0;
goto stop2;
}
}
}


// test the col 16-20 in the dataset
for (b4=5;b4>=0;--b4){
for (b3=3;b3>=0;--b3){
// if not infected 
if (data1(b1,b3+15+5*b4)==0){
// reject the data with infection 	
if (combination(b2,b3)==data1(b1,2)+b4+1-data1(b1,4)){
//consistent(b2,b1)=0;
goto stop2;
}
}	
}
if (data1(b1,19+5*b4)==0){
if ( (combination(b2,0)!=data1(b1,2)+b4+1-data1(b1,4))&&(combination(b2,1)!=data1(b1,2)+b4+1-data1(b1,4))&&(combination(b2,2)!=data1(b1,2)+b4+1-data1(b1,4))&&(combination(b2,3)!=data1(b1,2)+b4+1-data1(b1,4)) ){
//consistent(b2,b1)=0;
goto stop2;
}
}
}
consistent(counter,b1)=b2+1;
++counter;

stop2: ;
}
}


}
}
};


//########################################################################################################################################
//function to compute the combination and return a matrix to say if the case fit the combination
// [[Rcpp::export]]
List count_combination(NumericMatrix data1){ // to count the number of variable

IntegerMatrix combination(58625,4);
IntegerMatrix consistent(20000,data1.nrow());

int counter=1;
int b1;
int b2;
int b3;
int b4;
int b5;
int b6;
int b7;
int b8;
// for 1 infected sero type
for (b1=3;b1>=0;--b1){
for (b2=15;b2>=0;--b2){
combination(counter,b1)=b2+1;
++counter;
}	
}

// for 2 infected sero type
for (b1=3;b1>=0;--b1){
for (b2=3;b2>=0;--b2){
for (b3=15;b3>=0;--b3){
for (b4=15;b4>=0;--b4){
if ((b1>b2)&&(b3!=b4)){
combination(counter,b1)=b3+1;
combination(counter,b2)=b4+1;
++counter;
}
}
}
}
}

// for 3 infected sero type
for (b1=3;b1>=0;--b1){
for (b2=3;b2>=0;--b2){
for (b3=3;b3>=0;--b3){	
for (b4=15;b4>=0;--b4){	
for (b5=15;b5>=0;--b5){
for (b6=15;b6>=0;--b6){
if ((b1>b2)&&(b2>b3)&&(b4!=b5)&&(b5!=b6)&&(b4!=b6)){
combination(counter,b1)=b4+1;
combination(counter,b2)=b5+1;
combination(counter,b3)=b6+1;
++counter;
}
}
}
}
}
}
}

// for 4 infected sero type
for (b1=3;b1>=0;--b1){
for (b2=3;b2>=0;--b2){
for (b3=3;b3>=0;--b3){
for (b4=3;b4>=0;--b4){	
for (b5=15;b5>=0;--b5){	
for (b6=15;b6>=0;--b6){	
for (b7=15;b7>=0;--b7){
for (b8=15;b8>=0;--b8){
if ((b1>b2)&&(b2>b3)&&(b3>b4)&&(b5!=b6)&&(b5!=b7)&&(b5!=b8)&&(b6!=b7)&&(b6!=b8)&&(b7!=b8)){
combination(counter,b1)=b5+1;
combination(counter,b2)=b6+1;
combination(counter,b3)=b7+1;
combination(counter,b4)=b8+1;
++counter;
}
}
}
}
}
}
}
}
}

CheckConsistent checkconsistent(data1,combination,consistent);
// call parallelFor to do the work
parallelFor(0,data1.nrow(),checkconsistent);

return List::create(_[""]=combination,
_[""]=consistent);
} 



//########################################################################################################################################
//########################################################################################################################################
// the main body of the parallel for Digraphlikelihood
struct LogLikImpute:public Worker{
// source vector
RMatrix<double> out1;
RMatrix<double> out2;
RMatrix<double> out3;
RMatrix<int> data11;
RVector<int> data31;
RVector<double> para;
RMatrix<double> record;
// destination vector
// initialize with source and destination
LogLikImpute(NumericMatrix out1,
NumericMatrix out2,	
NumericMatrix out3,	
IntegerMatrix data11,
IntegerVector data31,
NumericVector para,
NumericMatrix record) 
:out1(out1),out2(out2),out3(out3),data11(data11),data31(data31),para(para),record(record){}
void operator()(std::size_t begin, std::size_t end) {

// section to write the parallel version
// functor (pass input and output matrixes)
for (unsigned int b1=begin;b1<end;++b1){	
int b2;
int b3;
int b4;
int b5;
int b6;
int b7;
int b8;
int counter2=0;
for (b5=1;b5>=0;--b5){
for (b6=1;b6>=0;--b6){
for (b7=1;b7>=0;--b7){
for (b8=1;b8>=0;--b8){
// create the symtpom profile and compare with the data, if not fit then reject and return -9999999 directly
data11(b1,6)=b5;
data11(b1,7)=b6;
data11(b1,8)=b7;
data11(b1,9)=b8;

// if no infection but with symptom = 1 then reject
for (b3=3;b3>=0;--b3){
if ((data11(b1,2+b3)==0)&&(data11(b1,6+b3)==1)){
out1(b1,counter2)=-9999999;	
}	
}

// start to compare with the real data
for (b2=5;b2>=0;--b2){
if (data31[b2]!=-1){
for (b3=3;b3>=0;--b3){
if (data11(b1,b3+2)==data11(b1,10)+1+b2-data11(b1,11)){
if (data11(b1,b3+6)!=data31[b2]){
out1(b1,counter2)=-9999999;
}
}
}
}
}



if (out1(b1,counter2)!=-9999999){
double p[4];
double covariate_eff_inf;
double covariate_eff_sym;
double sym_prob;
double inf_prob;
int infectstatus;		
int counter;
int numberofinfection=0;
int yearsincelastinfection=1;
int symptomlastinfection=0;
int agelastinfection=0;
int symptomallinfection=0;

for (b2=0;b2<=data11(b1,10)-1+data11(b1,12)-data11(b1,11);++b2){
//record(b1,b2)=data11(b1,1)+b2;
int infectedserotype=-1;
for (b4=3;b4>=0;--b4){
// serach the infected serotype
if (data11(b1,b4+2)==b2+1){
infectedserotype=b4;
}
}
// for the infection part
counter=0;
// count is it already infected all serotype
for (b4=3;b4>=0;--b4){
if ((data11(b1,b4+2)<b2+1)&&(data11(b1,b4+2)>0)){
++counter;
}	
}
if (counter==4){
goto stop1;
}
// compute covariate effect of infection
covariate_eff_inf=para[60]*(numberofinfection==1)+para[61]*(numberofinfection>=2); 
covariate_eff_inf+=(numberofinfection>0)*(para[62]*(yearsincelastinfection==1)+para[63]*(yearsincelastinfection==2));
//covariate_eff_inf+=(numberofinfection>0)*para[64]*(agelastinfection>=6);
covariate_eff_inf+=(numberofinfection>0)*para[64]*(symptomlastinfection==1);
// compute the probability for 4 serotype
p[0]=logit(para[data11(b1,1)+b2])+covariate_eff_inf;
p[1]=logit(para[15+data11(b1,1)+b2])+covariate_eff_inf;
p[2]=logit(para[30+data11(b1,1)+b2])+covariate_eff_inf;
p[3]=logit(para[45+data11(b1,1)+b2])+covariate_eff_inf;
p[0]=invlogit(p[0]);
p[1]=invlogit(p[1]);
p[2]=invlogit(p[2]);
p[3]=invlogit(p[3]);


for (b4=3;b4>=0;--b4){
// remove the already infected serotype
if ((data11(b1,b4+2)<b2+1)&&(data11(b1,b4+2)>0)){
p[b4]=0;
}
if (p[b4]==1){
p[b4]=0.9999999;	
}
//record(b1,b2*5+1+b4)=p[b4];
}

// if escape
if (infectedserotype==-1){
out1(b1,counter2)+=log(1-p[0])+log(1-p[1])+log(1-p[2])+log(1-p[3]);
}
// otherwise
else{
out1(b1,counter2)+=log(1-(1-p[0])*(1-p[1])*(1-p[2])*(1-p[3]));
for (b4=3;b4>=0;--b4){
if (b4!=infectedserotype){	
out1(b1,counter2)+=log(1-log(1-p[b4])/log((1-p[0])*(1-p[1])*(1-p[2])*(1-p[3])));	
}
}
out1(b1,counter2)+=log(log(1-p[infectedserotype])/log((1-p[0])*(1-p[1])*(1-p[2])*(1-p[3])));
}
//record(b1,b2*5+5)=log(1-(1-p[0])*(1-p[1])*(1-p[2])*(1-p[3]));
// for the sym part
// confirm it is infection
if (infectedserotype!=-1){
// compute the symptom probability
covariate_eff_sym=(numberofinfection>0)*(para[70]*(symptomallinfection==0)+para[71]*(symptomallinfection==1)); 
covariate_eff_sym+=(numberofinfection>0)*(para[72]*(yearsincelastinfection==1)+para[73]*(yearsincelastinfection==2));
//covariate_eff_sym+=para[74]*(agelastinfection>=6);
//covariate_eff_sym+=para[75]*(symptomlastinfection==1);		
// compute the symptom probability
sym_prob=logit(para[66+infectedserotype])+covariate_eff_sym;
sym_prob=invlogit(sym_prob);
if (data11(b1,infectedserotype+6)==1){
out2(b1,counter2)+=log(sym_prob);
}
else{
out2(b1,counter2)+=log(1-sym_prob);
}
}

// set the inforation that need to be used
// infected
if (infectedserotype!=-1){
++numberofinfection;
agelastinfection=b2+1;
// reset
yearsincelastinfection=1;
symptomlastinfection=data11(b1,infectedserotype+6);
if (data11(b1,infectedserotype+6)==1){
symptomallinfection=1;	
}

}
// non-infected
else{
++yearsincelastinfection;
}
}
stop1: ;

}
out3(b1,counter2)=out1(b1,counter2)+out2(b1,counter2);
++counter2;
}
}
}
}

}
}
};

//########################################################################################################################################
//function to compute likelihood for infection and symptom
// [[Rcpp::export]]
List loglik_impute(IntegerMatrix data11,
IntegerVector data31,
NumericVector para){
// check if the para are within their possible range
NumericMatrix out1(data11.nrow(),16);
NumericMatrix out2(data11.nrow(),16);
NumericMatrix out3(data11.nrow(),16);
NumericMatrix record(2,2);
// call parallel program
LogLikImpute loglikimpute(out1,out2,out3,data11,data31,para,record);
// call parallelFor to do the work
parallelFor(0,data11.nrow(),loglikimpute);

return List::create(_[""]=out1,
_[""]=out2,
_[""]=out3);
}




//########################################################################################################################################
//########################################################################################################################################
// the main body of the parallel for Digraphlikelihood
struct LogLikImpute2Serotype:public Worker{
// source vector
RMatrix<double> out1;
RMatrix<double> out2;
RMatrix<double> out3;
RMatrix<int> data11;
RVector<int> data31;
int serotypemove;
RVector<double> para;
RMatrix<double> record;
// destination vector
// initialize with source and destination
LogLikImpute2Serotype(NumericMatrix out1,
NumericMatrix out2,	
NumericMatrix out3,	
IntegerMatrix data11,
IntegerVector data31,
int serotypemove,
NumericVector para,
NumericMatrix record) 
:out1(out1),out2(out2),out3(out3),data11(data11),data31(data31),serotypemove(serotypemove),para(para),record(record){}
void operator()(std::size_t begin, std::size_t end) {

// section to write the parallel version
// functor (pass input and output matrixes)
for (unsigned int b1=begin;b1<end;++b1){	
int b2;
int b3;
int b4;
int b5;
int b6;
int b7;
int b8;
int counter2=0;

// first copy the data11 symptom as record
int currentsymptom[4];
for (b3=3;b3>=0;--b3){
currentsymptom[b3]=data11(b1,6+b3);
}

for (b5=1;b5>=0;--b5){
for (b6=1;b6>=0;--b6){
for (b7=1;b7>=0;--b7){
for (b8=1;b8>=0;--b8){
// create the symtpom profile and compare with the data, if not fit then reject and return -9999999 directly

int fix[4];

// create fixed set
if (serotypemove==0){
fix[0]=2;
fix[1]=3;
}
else if (serotypemove==1){
fix[0]=1;
fix[1]=3;
}
else if (serotypemove==2){
fix[0]=1;
fix[1]=2;
}
else if (serotypemove==3){
fix[0]=0;
fix[1]=3;
}
else if (serotypemove==4){
fix[0]=0;
fix[1]=2;
}
else if (serotypemove==5){
fix[0]=0;
fix[1]=1;
}


data11(b1,6)=b5;
data11(b1,7)=b6;
data11(b1,8)=b7;
data11(b1,9)=b8;

// if no infection but with symptom = 1 then reject
for (b3=3;b3>=0;--b3){
if ((data11(b1,2+b3)==0)&&(data11(b1,6+b3)==1)){
out1(b1,counter2)=-9999999;	
}	
}

// start to compare with the real data
for (b2=5;b2>=0;--b2){
if (data31[b2]!=-1){
for (b3=3;b3>=0;--b3){
if (data11(b1,b3+2)==data11(b1,10)+1+b2-data11(b1,11)){
if (data11(b1,b3+6)!=data31[b2]){
out1(b1,counter2)=-9999999;
}
}
}
}
}

// comparing with current conditionaling
for (b3=3;b3>=0;--b3){
if ((b3==fix[0])||b3==fix[1]){
if (currentsymptom[b3]!=data11(b1,6+b3)){
out1(b1,counter2)=-9999999;
}
}
}



if (out1(b1,counter2)!=-9999999){
double p[4];
double covariate_eff_inf;
double covariate_eff_sym;
double sym_prob;
double inf_prob;
int infectstatus;		
int counter;
int numberofinfection=0;
int yearsincelastinfection=1;
int symptomlastinfection=0;
int agelastinfection=0;
int symptomallinfection=0;

for (b2=0;b2<=data11(b1,10)-1+data11(b1,12)-data11(b1,11);++b2){
//record(b1,b2)=data11(b1,1)+b2;
int infectedserotype=-1;
for (b4=3;b4>=0;--b4){
// serach the infected serotype
if (data11(b1,b4+2)==b2+1){
infectedserotype=b4;
}
}
// for the infection part
counter=0;
// count is it already infected all serotype
for (b4=3;b4>=0;--b4){
if ((data11(b1,b4+2)<b2+1)&&(data11(b1,b4+2)>0)){
++counter;
}	
}
if (counter==4){
goto stop1;
}
// compute covariate effect of infection
covariate_eff_inf=para[60]*(numberofinfection==1)+para[61]*(numberofinfection>=2); 
covariate_eff_inf+=(numberofinfection>0)*(para[62]*(yearsincelastinfection==1)+para[63]*(yearsincelastinfection==2));
//covariate_eff_inf+=(numberofinfection>0)*para[64]*(agelastinfection>=6);
covariate_eff_inf+=(numberofinfection>0)*para[64]*(symptomlastinfection==1);
// compute the probability for 4 serotype
p[0]=logit(para[data11(b1,1)+b2])+covariate_eff_inf;
p[1]=logit(para[15+data11(b1,1)+b2])+covariate_eff_inf;
p[2]=logit(para[30+data11(b1,1)+b2])+covariate_eff_inf;
p[3]=logit(para[45+data11(b1,1)+b2])+covariate_eff_inf;
p[0]=invlogit(p[0]);
p[1]=invlogit(p[1]);
p[2]=invlogit(p[2]);
p[3]=invlogit(p[3]);


for (b4=3;b4>=0;--b4){
// remove the already infected serotype
if ((data11(b1,b4+2)<b2+1)&&(data11(b1,b4+2)>0)){
p[b4]=0;
}
if (p[b4]==1){
p[b4]=0.9999999;	
}
//record(b1,b2*5+1+b4)=p[b4];
}

// if escape
if (infectedserotype==-1){
out1(b1,counter2)+=log(1-p[0])+log(1-p[1])+log(1-p[2])+log(1-p[3]);
}
// otherwise
else{
out1(b1,counter2)+=log(1-(1-p[0])*(1-p[1])*(1-p[2])*(1-p[3]));
for (b4=3;b4>=0;--b4){
if (b4!=infectedserotype){	
out1(b1,counter2)+=log(1-log(1-p[b4])/log((1-p[0])*(1-p[1])*(1-p[2])*(1-p[3])));	
}
}
out1(b1,counter2)+=log(log(1-p[infectedserotype])/log((1-p[0])*(1-p[1])*(1-p[2])*(1-p[3])));
}
//record(b1,b2*5+5)=log(1-(1-p[0])*(1-p[1])*(1-p[2])*(1-p[3]));
// for the sym part
// confirm it is infection
if (infectedserotype!=-1){
// compute the symptom probability
covariate_eff_sym=(numberofinfection>0)*(para[70]*(symptomallinfection==0)+para[71]*(symptomallinfection==1)); 
covariate_eff_sym+=(numberofinfection>0)*(para[72]*(yearsincelastinfection==1)+para[73]*(yearsincelastinfection==2));
//covariate_eff_sym+=para[74]*(agelastinfection>=6);
//covariate_eff_sym+=para[75]*(symptomlastinfection==1);	
// compute the symptom probability
sym_prob=logit(para[66+infectedserotype])+covariate_eff_sym;
sym_prob=invlogit(sym_prob);
if (data11(b1,infectedserotype+6)==1){
out2(b1,counter2)+=log(sym_prob);
}
else{
out2(b1,counter2)+=log(1-sym_prob);
}
}

// set the inforation that need to be used
// infected
if (infectedserotype!=-1){
++numberofinfection;
agelastinfection=b2+1;
// reset
yearsincelastinfection=1;
symptomlastinfection=data11(b1,infectedserotype+6);
if (data11(b1,infectedserotype+6)==1){
symptomallinfection=1;	
}

}
// non-infected
else{
++yearsincelastinfection;
}
}
stop1: ;

}
out3(b1,counter2)=out1(b1,counter2)+out2(b1,counter2);
++counter2;
}
}
}
}

}
}
};

//########################################################################################################################################
//function to compute likelihood for infection and symptom
// [[Rcpp::export]]
List loglik_impute_2serotype(IntegerMatrix data11,
IntegerVector data31,
int serotypemove,
NumericVector para){
// check if the para are within their possible range
NumericMatrix out1(data11.nrow(),16);
NumericMatrix out2(data11.nrow(),16);
NumericMatrix out3(data11.nrow(),16);
NumericMatrix record(2,2);
// call parallel program
LogLikImpute2Serotype loglikimpute2serotype(out1,out2,out3,data11,data31,serotypemove,para,record);
// call parallelFor to do the work
parallelFor(0,data11.nrow(),loglikimpute2serotype);

return List::create(_[""]=out1,
_[""]=out2,
_[""]=out3);
}


//########################################################################################################################################
//########################################################################################################################################
// the main body of the parallel for check consistent
struct CheckConsistentImpute:public Worker{
// source vector
RMatrix<int> data11;
RMatrix<int> combination;
RVector<int> serotypemove;
RMatrix<int> consistent;
RMatrix<int> consistentimpute;
RVector<int> numberofchoose;
// destination vector
// initialize with source and destination
CheckConsistentImpute(IntegerMatrix data11,
IntegerMatrix combination,
IntegerVector serotypemove,
IntegerMatrix consistent,
IntegerMatrix consistentimpute,
IntegerVector numberofchoose) 
:data11(data11),combination(combination),serotypemove(serotypemove),consistent(consistent),consistentimpute(consistentimpute),numberofchoose(numberofchoose){}
void operator()(std::size_t begin, std::size_t end) {

// section to write the parallel version
// functor (pass input and output matrixes)
for (unsigned int b1=begin;b1<end;++b1){


int b2;
int b3;
int b4;
int counter=0;
// create fixed set
int fix[2];
if (serotypemove[b1]==0){
fix[0]=2;
fix[1]=3;
}
else if (serotypemove[b1]==1){
fix[0]=1;
fix[1]=3;
}
else if (serotypemove[b1]==2){
fix[0]=1;
fix[1]=2;
}
else if (serotypemove[b1]==3){
fix[0]=0;
fix[1]=3;
}
else if (serotypemove[b1]==4){
fix[0]=0;
fix[1]=2;
}
else if (serotypemove[b1]==5){
fix[0]=0;
fix[1]=1;
}

// start from the full consistent list
for (b2=numberofchoose[b1];b2>=0;--b2){

// also drop all combination that not fit the data11
for (b3=3;b3>=0;--b3){
if ((b3==fix[0])||(b3==fix[1])){
if (combination(consistent(b2,b1)-1,b3)!=data11(b1,b3+2)){
goto stop4;
}
}
}

consistentimpute(counter,b1)=consistent(b2,b1);
++counter;

stop4: ;

}


}
}
};



//########################################################################################################################################
//function to compute the combination and return a matrix to say if the case fit the combination
// [[Rcpp::export]]
IntegerMatrix consistent_impute_2serotype(IntegerMatrix data11,
IntegerMatrix combination,
IntegerMatrix consistent,
IntegerVector numberofchoose,
IntegerVector serotypemove){ // to count the number of variable

IntegerMatrix consistentimpute(500,data11.nrow());

// rememeber need to +1, 0 means empty here
// eg, 2 means second row, not third row

CheckConsistentImpute checkconsistentimpute(data11,combination,serotypemove,consistent,consistentimpute,numberofchoose);
// call parallelFor to do the work
parallelFor(0,data11.nrow(),checkconsistentimpute);

return consistentimpute;
} 

//##############################################################################################################################################
//##############################################################################################################################################
// function for mcmc
// [[Rcpp::export]]
List mcmc(NumericMatrix data1, //IntegerMatrix data11,IntegerMatrix data21,
IntegerMatrix data21, // the real surviellance data
IntegerMatrix data31, // symptom data with 1 0
IntegerMatrix combination,  
IntegerMatrix consistent,   
NumericVector adjfactor, 
int mcmc_n,             // length of mcmc stain
NumericVector int_para, // initial parameter
int startcol,
NumericVector move,     // which one should move in the model
NumericVector sigma){            

// create the vector for use
int b0;
int b1;
int b2;
int b3;
int b4;
int moveindex;
//####################################################################################################################################
// need to generate a data that is consistent with the orignal data

IntegerMatrix data11;
// count the total number of choose for each individual
IntegerVector numberofchoose(data1.nrow());
for (b1=data1.nrow()-1;b1>=0;--b1){
for (b2=consistent.nrow()-1;b2>=0;--b2){
if (consistent(b2,b1)!=0){
numberofchoose(b1)=b2;
break;
}
}
}



// count the number of infection for the data
IntegerMatrix countinfection(4,15);

List temp2;
temp2=sim_data(data1,int_para,int_para,adjfactor);
IntegerMatrix data111=temp2(0);

// first for all cases, randomly select one scenario that consistent with the data
for (b1=data111.nrow()-1;b1>=0;--b1){
int siminteger=0; //rand()%(1+numberofchoose(b1));
for (b2=3;b2>=0;--b2){
data111(b1,b2+2)=combination(consistent(siminteger,b1)-1,b2);	
}
// first reset all non-infection to have no symptom
for (b2=3;b2>=0;--b2){
if (data111(b1,b2+2)==0){
data111(b1,b2+6)=0;	
}
}
}

// fit the information of the symptom data 
// run from the symptom matrix
for (b1=data111.nrow()-1;b1>=0;--b1){
for (b2=5;b2>=0;--b2){
if (data31(b1,b2)!=-1){
for (b3=3;b3>=0;--b3){
if (data111(b1,b3+2)!=0){
// test if the infection year is same for the study year and get the information of symptom of study year
if (data111(b1,b3+2)==data1(b1,2)+1+b2-data1(b1,4)){
data111(b1,b3+6)=data31(b1,b2);
}
}
}
}
}
}

// for the infection that before study, have some chance to be symptomatic infeciton
for (b1=data111.nrow()-1;b1>=0;--b1){
for (b2=3;b2>=0;--b2){
if ((data111(b1,b2+2)<data1(b1,2)+1-data1(b1,4))&&(data111(b1,b2+2)>0)){
data111(b1,b2+6)=gen_binom(0.02);
}
}
}

// count the number of infection for the data
IntegerMatrix countinfection1(4,15);
for (b1=data111.nrow()-1;b1>=0;--b1){
for (b2=3;b2>=0;--b2){
if (data111(b1,b2+2)!=0){
++countinfection1(b2,data111(b1,b2+2)+data111(b1,1)-1);
}
}
}

data11=clone(data111);
countinfection=clone(countinfection1);	



// need to set number of parameter here
NumericMatrix p_para(mcmc_n,int_para.length());
NumericMatrix p_para_r(mcmc_n,sum(move));
p_para(0,_)=int_para;
moveindex=sum(move)-1;
for (b1=int_para.length()-1;b1>=0;--b1){
if (move(b1)){
p_para_r(0,moveindex)=p_para(0,b1);
--moveindex;
}	
}

// matrix to record LL
NumericVector acceptrate(int_para.length());
NumericMatrix LL1(mcmc_n,4);
NumericVector datalik(data1.nrow());
NumericVector datasymlik(data1.nrow());
NumericMatrix nblik(4,15);
NumericVector datalikpro(data1.nrow());
NumericVector datasymlikpro(data1.nrow());
NumericMatrix nblikpro(4,15);
IntegerMatrix countinfectionrecord(mcmc_n,60);

for (b1=59;b1>=0;--b1){
countinfectionrecord(0,b1)=countinfection(b1/15,b1%15);	
}

//####################################################################################################################################
// initial step
// impute missing 

//####################################################################################################################################
// compute likelihood

datalik=loglik(data11,p_para(0,_),1,0);
datasymlik=loglik(data11,p_para(0,_),0,1);


for (b1=3;b1>=0;--b1){
for (b2=14;b2>=startcol;--b2){
nblik(b1,b2)=dnb(data21(b1,b2),countinfection(b1,b2)*adjfactor(b2),p_para(0,76));
}
}
LL1(0,1)=sum(datalik);
LL1(0,2)=sum(datasymlik);
LL1(0,3)=sum(nblik);
LL1(0,0)=LL1(0,1)+LL1(0,2)+LL1(0,3);

NumericVector temploglik(4);
NumericVector newloglik(4);
temploglik(0)=LL1(0,0)+prior_loglik(p_para(0,_));
temploglik(1)=LL1(0,1);
temploglik(2)=LL1(0,2);
temploglik(3)=LL1(0,3);

double loglikeratio;
double accept_pro;
NumericVector pro_para(int_para.length());


//####################################################################################################################################
// main mcmc step
NumericMatrix record_mcmc1(mcmc_n,int_para.length());
NumericMatrix record_mcmc2(mcmc_n,int_para.length());
NumericMatrix record_mcmc3(mcmc_n,int_para.length());
NumericMatrix record_mcmc4(mcmc_n,int_para.length());
NumericMatrix record_mcmc5(mcmc_n,int_para.length());


//NumericMatrix dataimputelik1;
//NumericMatrix dataimputesymlik1;
//NumericMatrix dataimputeliktotal1;
//IntegerMatrix dataimpute1;
//IntegerVector serotypechoose1;
//IntegerMatrix consistentimpute1;
//IntegerVector numberofchooseimpute1;


IntegerMatrix symptommatrix(16,4);

int counter3=0;

// create the symptom matrix
for (int b5=1;b5>=0;--b5){
for (int b6=1;b6>=0;--b6){
for (int b7=1;b7>=0;--b7){
for (int b8=1;b8>=0;--b8){
symptommatrix(counter3,0)=b5;
symptommatrix(counter3,1)=b6;
symptommatrix(counter3,2)=b7;
symptommatrix(counter3,3)=b8;
++counter3;
}
}
}
}

NumericVector empmean(int_para.length());
NumericVector empsigma(int_para.length());

//####################################################################################################################################
for (b0=1;b0<mcmc_n;++b0){

// after 500 step, then set the sigma to be the empirical sigma
if (b0>500){
for (b1=int_para.length()-1;b1>=0;--b1){
if (move(b1)){	
NumericVector temp1(b0-1);
for (b2=b0-2;b2>=0;--b2){
temp1(b2)=p_para(b2,b1);	
}
sigma(b1)=sd(temp1);
// tuning
if (acceptrate(b1)<0.1){
sigma(b1)*=0.5;
}	
if ((acceptrate(b1)<0.15)&(acceptrate(b1)>0.1)){
sigma(b1)*=0.8;
}
if ((acceptrate(b1)<0.2)&(acceptrate(b1)>0.15)){
sigma(b1)*=0.95;
}
if ((acceptrate(b1)<0.4)&(acceptrate(b1)>0.3)){
sigma(b1)*=1.05;
}
if ((acceptrate(b1)<0.9)&(acceptrate(b1)>0.4)){
sigma(b1)*=1.2;
}
if (acceptrate(b1)>0.9){
sigma(b1)*=2;
}
}
}
}


// metorpolis-hasing update on parameter

for (b1=0;b1<int_para.length();++b1){
if (move(b1)){
pro_para=p_para(b0-1,_);
for (b2=b1-1;b2>=0;--b2){
pro_para(b2)=p_para(b0,b2);	
}
pro_para(b1)+=rnorm(0.0,sigma(b1));
//record_mcmc1(b0,3*b1)=pro_para(b1);
newloglik(0)=prior_loglik(pro_para);
if (newloglik(0)> -9999999){
if (b1<66){
datalikpro=loglik(data11,pro_para,1,0);
newloglik(1)=sum(datalikpro);
newloglik(2)=temploglik(2);
newloglik(3)=temploglik(3);
}
else if(b1>=76){
for (b2=3;b2>=0;--b2){
for (b3=14;b3>=startcol;--b3){
nblikpro(b2,b3)=dnb(data21(b2,b3),countinfection(b2,b3)*adjfactor(b3),pro_para(76));
}
}
newloglik(1)=temploglik(1);
newloglik(2)=temploglik(2);
newloglik(3)=sum(nblikpro);
}
else{
datasymlikpro=loglik(data11,pro_para,0,1);	
newloglik(1)=temploglik(1);
newloglik(2)=sum(datasymlikpro);
newloglik(3)=temploglik(3);
}
newloglik(0)+=newloglik(1)+newloglik(2)+newloglik(3);
loglikeratio=newloglik(0)-temploglik(0);
accept_pro=pow(exp(1),loglikeratio);
}
else{
accept_pro=0;	
}
record_mcmc2(b0,b1)=accept_pro;
record_mcmc3(b0,b1)=sum(datasymlikpro);
record_mcmc4(b0,b1)=sum(datasymlik);
//record_mcmc1(b0,3*b1+1)=loglikeratio;
if(gen_binom(accept_pro)){
//record_mcmc1(b0,3*b1+2)=1;
if (b1<66){	
datalik=clone(datalikpro);
}
else if(b1>=76){
nblik=clone(nblikpro);	
}
else{
datasymlik=clone(datasymlikpro);
}	
p_para(b0,b1)=pro_para(b1);
temploglik(0)=newloglik(0);
temploglik(1)=newloglik(1);
temploglik(2)=newloglik(2);
temploglik(3)=newloglik(3);
acceptrate(b1)*=(b0-1);
acceptrate(b1)+=1;
acceptrate(b1)/=b0;
}
else{
p_para(b0,b1)=p_para(b0-1,b1);
acceptrate(b1)*=(b0-1);
acceptrate(b1)/=b0;
}
}
else {
p_para(b0,b1)=p_para(b0-1,b1);
}
}

LL1(b0,0)=temploglik(0)-prior_loglik(p_para(b0,_));
LL1(b0,1)=temploglik(1);
LL1(b0,2)=temploglik(2);
LL1(b0,3)=temploglik(3);

for (b1=3;b1>=0;--b1){
record_mcmc5(b0,b1)=LL1(b0,b1);
}

// move the matirx to another matrix to store the parameter and compute the correlation matrix
moveindex=sum(move)-1;
for (b1=int_para.length()-1;b1>=0;--b1){
if (move(b1)){
p_para_r(b0,moveindex)=p_para(b0,b1);
--moveindex;
}	
}


// update version 2, random selectly 2 serotype first, conditional on other serotype, and then update another 2
// first draw random number from 0-5: denote
// 0: 1+2, 1: 1+3, 2: 1+4, 3: 2+3, 4: 2+4, 5: 3+4
// hence the opposite would be 5-choose
// eg, 0 paired with 5, 1 paried with 4 etc
IntegerVector serotypechoose(data1.nrow());
for (b1=data1.nrow()-1;b1>=0;--b1){
serotypechoose(b1)=rand()%6;
}
// after selecting the serotype that can move, need to create a matrix to contain the possible combination
// inpute the current data and also the combination matrix, to extract the subset that can fit the current data

for (int tempindex=1;tempindex>=0;--tempindex){

if (tempindex==0){
for (b1=data1.nrow()-1;b1>=0;--b1){
serotypechoose(b1)=5-serotypechoose(b1);	
}	
}

IntegerMatrix consistentimpute=consistent_impute_2serotype(data11,combination,consistent,numberofchoose,serotypechoose);

IntegerVector numberofchooseimpute(data1.nrow());
for (b1=data1.nrow()-1;b1>=0;--b1){
for (b2=consistentimpute.nrow()-1;b2>=0;--b2){
if (consistentimpute(b2,b1)!=0){
numberofchooseimpute(b1)=b2;
break;
}
}
}

for (b1=data1.nrow()-1;b1>=0;--b1){
//for (b1=0;b1>=0;--b1){
IntegerMatrix dataimpute(numberofchooseimpute(b1)+1,13);
// create the data set and used the likelihood function to compute
for (b2=dataimpute.nrow()-1;b2>=0;--b2){
dataimpute(b2,1)=data11(b1,1);
for (b3=3;b3>=0;--b3){
dataimpute(b2,b3+2)=combination(consistentimpute(b2,b1)-1,b3);
}
// put the background information in the imputed data and also the current symptom data
for (b3=6;b3>=0;--b3){
dataimpute(b2,b3+6)=data11(b1,b3+6);
}
}
// need to hand symptom in the likelihood
// output the likelihood matrix with nrow*16, with all possible symtpom combination
List loglikall=loglik_impute_2serotype(dataimpute,data31(b1,_),serotypechoose(b1),p_para(b0,_));
NumericMatrix dataimputelik=loglikall(0);
NumericMatrix dataimputesymlik=loglikall(1);
NumericMatrix dataimputeliktotal=loglikall(2);

//serotypechoose1=clone(serotypechoose);
//consistentimpute1=clone(consistentimpute);
//numberofchooseimpute1=clone(numberofchooseimpute);
//dataimputelik1=clone(dataimputelik);
//dataimputesymlik1=clone(dataimputesymlik);
//dataimputeliktotal1=clone(dataimputeliktotal);
//dataimpute1=clone(dataimpute);

// need to add the surviellance part in the likelihood
// to compute the NB component in the imputation
// using the current imputation result as a basline, all scanerio were compared with this

for (b2=dataimpute.nrow()-1;b2>=0;--b2){
for (b3=3;b3>=0;--b3){
// so only need to compute when the imputation data change the number of symptomatic infection
// and hence will change the NB likelihood
if (dataimpute(b2,b3+2)!=data11(b1,b3+2)){
// if change from a symptomatic infection to non-infection	
if (dataimpute(b2,b3+2)==0){
double tempvalue1=dnb(data21(b3,data11(b1,b3+2)+data11(b1,1)-1), (countinfection(b3,data11(b1,b3+2)+data11(b1,1)-1)-1)*adjfactor(data11(b1,b3+2)+data11(b1,1)-1) , p_para(b0,76));	
for (b4=15;b4>=0;--b4){	
dataimputeliktotal(b2,b4)+=tempvalue1;
dataimputeliktotal(b2,b4)-=nblik(b3,data11(b1,b3+2)+data11(b1,1)-1);
}
}
// if change from non-infection to infection
if (data11(b1,b3+2)==0){
double tempvalue1=dnb(data21(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1), (countinfection(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1)+1)*adjfactor(dataimpute(b2,b3+2)+dataimpute(b2,1)-1), p_para(b0,76));	
for (b4=15;b4>=0;--b4){	
dataimputeliktotal(b2,b4)+=tempvalue1;
dataimputeliktotal(b2,b4)-=nblik(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1);
}
}
// change from the year of the infection
if ((data11(b1,b3+2)!=0)&&(dataimpute(b2,b3+2)!=0)){
double tempvalue1=dnb(data21(b3,data11(b1,b3+2)+data11(b1,1)-1), (countinfection(b3,data11(b1,b3+2)+data11(b1,1)-1)-1)*adjfactor(data11(b1,b3+2)+data11(b1,1)-1) , p_para(b0,76));
double tempvalue2=dnb(data21(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1), (countinfection(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1)+1)*adjfactor(dataimpute(b2,b3+2)+dataimpute(b2,1)-1)  , p_para(b0,76));		
for (b4=15;b4>=0;--b4){		
dataimputeliktotal(b2,b4)+=tempvalue1;
dataimputeliktotal(b2,b4)-=nblik(b3,data11(b1,b3+2)+data11(b1,1)-1);
dataimputeliktotal(b2,b4)+=tempvalue2;
dataimputeliktotal(b2,b4)-=nblik(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1);
}
}
}	
}
}


// modify the value to likelihood
for (b3=15;b3>=0;--b3){
for (b2=dataimpute.nrow()-1;b2>=0;--b2){
dataimputeliktotal(b2,b3)=exp(dataimputeliktotal(b2,b3));
} 
}


// do randomly drawing
//record_mcmc1(b0,0)=sum(likimpute);
double simvalue=(double)rand()/(RAND_MAX);
//record_mcmc1(b0,3)=simvalue;
simvalue*=sum(dataimputeliktotal);
//record_mcmc1(b0,1)=simvalue;
for (b4=15;b4>=0;--b4){
for (b2=dataimpute.nrow()-1;b2>=0;--b2){
simvalue-=dataimputeliktotal(b2,b4);
// decide to select this scenario, also need to update the likelihood and the nb companent and also its likelihood
if (simvalue<=0){		
// update the count and also the association nb likelihood
for (b3=3;b3>=0;--b3){
// so only need to compute when differ from the current imputation result
if (dataimpute(b2,b3+2)!=data11(b1,b3+2)){
// if change from infection to non-infection	
if (dataimpute(b2,b3+2)==0){
nblik(b3,data11(b1,b3+2)+data11(b1,1)-1)=dnb(data21(b3,data11(b1,b3+2)+data11(b1,1)-1), (countinfection(b3,data11(b1,b3+2)+data11(b1,1)-1)-1)*adjfactor(data11(b1,b3+2)+data11(b1,1)-1)  , p_para(b0,76));	
--countinfection(b3,data11(b1,b3+2)+data11(b1,1)-1);
}
// if change from non-infection to infection
if (data11(b1,b3+2)==0){
nblik(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1)=dnb(data21(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1), (countinfection(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1)+1)*adjfactor(dataimpute(b2,b3+2)+dataimpute(b2,1)-1), p_para(b0,76));	
++countinfection(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1);
}
// change from the year of the infection
if (data11(b1,b3+2)!=0&&dataimpute(b2,b3+2)!=0){
nblik(b3,data11(b1,b3+2)+data11(b1,1)-1)=dnb(data21(b3,data11(b1,b3+2)+data11(b1,1)-1), (countinfection(b3,data11(b1,b3+2)+data11(b1,1)-1)-1)*adjfactor(data11(b1,b3+2)+data11(b1,1)-1), p_para(b0,76));	
--countinfection(b3,data11(b1,b3+2)+data11(b1,1)-1);
nblik(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1)=dnb(data21(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1), (countinfection(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1)+1)*adjfactor(dataimpute(b2,b3+2)+dataimpute(b2,1)-1), p_para(b0,76));	
++countinfection(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1);
}
}	
}
// update the data
//record_mcmc1(b0,2)=b2;	
for (b3=3;b3>=0;--b3){
data11(b1,b3+2)=dataimpute(b2,b3+2);
data11(b1,b3+6)=symptommatrix(b4,b3);	
}
// update the likelihood
// need to be careful becasue imputelike involve the symptom likelihood, need to seperate this

//Rcout << "b1-1: " << datalik(b1) - dataimputelik(b2,b4) << std::endl;
//Rcout << "b1-2: " << datasymlik(b1) - dataimputesymlik(b2,b4) << std::endl;

datasymlik(b1)=dataimputesymlik(b2,b4);
datalik(b1)=dataimputelik(b2,b4);
//Rcout << "b1: " << b1 << std::endl;
goto stop5;
}
}
}
stop5: ;



}

}


/*
// update version 1, consider all serotype and impute together
// for 7 year histroy, still can handle, around 8 hours for 10000 mcmc run
// update the infection path in here
for (b1=data1.nrow()-1;b1>=0;--b1){
//for (b1=3;b1>=3;--b1){		
IntegerMatrix dataimpute(numberofchoose(b1)+1,13);
// create the data set and used the likelihood function to compute
for (b2=dataimpute.nrow()-1;b2>=0;--b2){
dataimpute(b2,1)=data11(b1,1);
for (b3=3;b3>=0;--b3){
dataimpute(b2,b3+2)=combination(consistent(b2,b1)-1,b3);
}
// put the background information in the imputed data
for (b3=2;b3>=0;--b3){
dataimpute(b2,b3+10)=data11(b1,b3+10);
}
}
// need to hand symptom in the likelihood
// output the likelihood matrix with nrow*16, with all possible symtpom combination
List loglikall=loglik_impute(dataimpute,data31(b1,_),p_para(b0,_));
NumericMatrix dataimputelik=loglikall(0);
NumericMatrix dataimputesymlik=loglikall(1);
NumericMatrix dataimputeliktotal=loglikall(2);

//dataimputelik1=clone(dataimputelik);
//dataimputesymlik1=clone(dataimputesymlik);
//dataimputeliktotal1=clone(dataimputeliktotal);

// need to add the surviellance part in the likelihood
// to compute the NB component in the imputation
// using the current imputation result as a basline, all scanerio were compared with this

for (b2=dataimpute.nrow()-1;b2>=0;--b2){
for (b3=3;b3>=0;--b3){
// so only need to compute when differ from the current imputation result
if (dataimpute(b2,b3+2)!=data11(b1,b3+2)){
// if change from infection to non-infection	
if (dataimpute(b2,b3+2)==0){
double tempvalue1=R::dnbinom(data21(b3,data11(b1,b3+2)+data11(b1,1)-1), countinfection(b3,data11(b1,b3+2)+data11(b1,1)-1)-1, p_para(b0,76),1);	
for (b4=15;b4>=0;--b4){	
dataimputeliktotal(b2,b4)+=tempvalue1;
dataimputeliktotal(b2,b4)-=nblik(b3,data11(b1,b3+2)+data11(b1,1)-1);
}
}
// if change from non-infection to infection
if (data11(b1,b3+2)==0){
double tempvalue1=R::dnbinom(data21(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1), countinfection(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1)+1, p_para(b0,76),1);	
for (b4=15;b4>=0;--b4){		
dataimputeliktotal(b2,b4)+=tempvalue1;
dataimputeliktotal(b2,b4)-=nblik(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1);
}
}
// change from the year of the infection
if (data11(b1,b3+2)!=0&&dataimpute(b2,b3+2)!=0){
double tempvalue1=R::dnbinom(data21(b3,data11(b1,b3+2)+data11(b1,1)-1), countinfection(b3,data11(b1,b3+2)+data11(b1,1)-1)-1, p_para(b0,76),1);
double tempvalue2=R::dnbinom(data21(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1), countinfection(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1)+1, p_para(b0,76),1);		
for (b4=15;b4>=0;--b4){		
dataimputeliktotal(b2,b4)+=tempvalue1;
dataimputeliktotal(b2,b4)-=nblik(b3,data11(b1,b3+2)+data11(b1,1)-1);
dataimputeliktotal(b2,b4)+=tempvalue2;
dataimputeliktotal(b2,b4)-=nblik(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1);
}
}
}	
}
}

// modify the value to likelihood
for (b3=15;b3>=0;--b3){
for (b2=dataimpute.nrow()-1;b2>=0;--b2){
dataimputeliktotal(b2,b3)=exp(dataimputeliktotal(b2,b3));
} 
}



// do randomly drawing
//record_mcmc1(b0,0)=sum(likimpute);
double simvalue=(double)rand()/(RAND_MAX);
//record_mcmc1(b0,3)=simvalue;
simvalue*=sum(dataimputeliktotal);
//record_mcmc1(b0,1)=simvalue;
for (b4=15;b4>=0;--b4){
for (b2=dataimpute.nrow()-1;b2>=0;--b2){
simvalue-=dataimputeliktotal(b2,b4);
// decide to select this scenario, also need to update the likelihood and the nb companent and also its likelihood
if (simvalue<=0){		
// update the count and also the association nb likelihood
for (b3=3;b3>=0;--b3){
// so only need to compute when differ from the current imputation result
if (dataimpute(b2,b3+2)!=data11(b1,b3+2)){
// if change from infection to non-infection	
if (dataimpute(b2,b3+2)==0){
nblik(b3,data11(b1,b3+2)+data11(b1,1)-1)=R::dnbinom(data21(b3,data11(b1,b3+2)+data11(b1,1)-1), countinfection(b3,data11(b1,b3+2)+data11(b1,1)-1)-1, p_para(b0,76),1);	
--countinfection(b3,data11(b1,b3+2)+data11(b1,1)-1);
}
// if change from non-infection to infection
if (data11(b1,b3+2)==0){
nblik(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1)=R::dnbinom(data21(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1), countinfection(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1)+1, p_para(b0,76),1);	
++countinfection(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1);
}
// change from the year of the infection
if (data11(b1,b3+2)!=0&&dataimpute(b2,b3+2)!=0){
nblik(b3,data11(b1,b3+2)+data11(b1,1)-1)=R::dnbinom(data21(b3,data11(b1,b3+2)+data11(b1,1)-1), countinfection(b3,data11(b1,b3+2)+data11(b1,1)-1)-1, p_para(b0,76),1);	
nblik(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1)=R::dnbinom(data21(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1), countinfection(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1)+1, p_para(b0,76),1);	
--countinfection(b3,data11(b1,b3+2)+data11(b1,1)-1);
++countinfection(b3,dataimpute(b2,b3+2)+dataimpute(b2,1)-1);
}
}	
}
// update the data
//record_mcmc1(b0,2)=b2;	
for (b3=3;b3>=0;--b3){
data11(b1,b3+2)=dataimpute(b2,b3+2);
data11(b1,b3+6)=symptommatrix(b4,b3);	
}
// update the likelihood
// need to be careful becasue imputelike involve the symptom likelihood, need to seperate this

//Rcout << "b1-1: " << datalik(b1) - dataimputelik(b2,b4) << std::endl;
//Rcout << "b1-2: " << datasymlik(b1) - dataimputesymlik(b2,b4) << std::endl;

datasymlik(b1)=dataimputesymlik(b2,b4);
datalik(b1)=dataimputelik(b2,b4);
//Rcout << "b1: " << b1 << std::endl;
goto stop3;
}
}
}
stop3: ;


}
*/


// update the impute likelihood

LL1(b0,1)=sum(datalik);
LL1(b0,2)=sum(datasymlik);
LL1(b0,3)=sum(nblik);
LL1(b0,0)=LL1(b0,1)+LL1(b0,2)+LL1(b0,3);

temploglik(0)=LL1(b0,0)+prior_loglik(p_para(b0,_));
temploglik(1)=LL1(b0,1);
temploglik(2)=LL1(b0,2);
temploglik(3)=LL1(b0,3);



for (b1=59;b1>=0;--b1){
countinfectionrecord(b0,b1)=countinfection(b1/15,b1%15);	
}

if (b0%100==1){
Rcout << "b0: " << b0 << std::endl;
Rcout << std::time(0) << std::endl;
}

}


return List::create(_[""]=p_para,
_[""]=LL1,
_[""]=record_mcmc1,
_[""]=record_mcmc2,
_[""]=record_mcmc3,
_[""]=record_mcmc4,
_[""]=record_mcmc5,
_[""]=data11,
_[""]=symptommatrix,
_[""]=countinfectionrecord,
_[""]=acceptrate);
} 



